package de.stundenkonto.grueter;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private View topSystemBar;

    private static final int FOREST = Color.rgb(8, 73, 64);
    private static final int CREAM = Color.rgb(247, 243, 233);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(CREAM);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            getWindow().setNavigationBarContrastEnforced(false);
        }

        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);

        root = new FrameLayout(this);
        root.setBackgroundColor(CREAM);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(CREAM);
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(webView, webLp);

        topSystemBar = new View(this);
        topSystemBar.setBackgroundColor(FOREST);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 0, Gravity.TOP);
        root.addView(topSystemBar, topLp);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top, bottom, left, right;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets safe = insets.getInsets(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                                | WindowInsets.Type.displayCutout());
                top = safe.top; bottom = safe.bottom; left = safe.left; right = safe.right;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
                left = insets.getSystemWindowInsetLeft();
                right = insets.getSystemWindowInsetRight();
            }

            FrameLayout.LayoutParams wlp = (FrameLayout.LayoutParams) webView.getLayoutParams();
            // Oben bleibt die Statusleiste ausgespart. Unten darf die WebView bis an
            // die Systemnavigation reichen. So entsteht kein zweiter, leerer
            // Sicherheitsbereich zwischen App-Navigation und Samsung-Navigation.
            wlp.setMargins(left, top, right, 0);
            webView.setLayoutParams(wlp);

            FrameLayout.LayoutParams tlp = (FrameLayout.LayoutParams) topSystemBar.getLayoutParams();
            tlp.height = top; topSystemBar.setLayoutParams(tlp);
            return insets;
        });
        root.requestApplyInsets();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.loadUrl("file:///android_asset/index.html");
    }

    public class AndroidBridge {
        @JavascriptInterface
        public void printPage(String jobName) {
            runOnUiThread(() -> {
                if (webView == null) return;
                try {
                    PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                    PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(
                            jobName == null || jobName.trim().isEmpty() ? "Stundenkonto" : jobName);
                    printManager.print(jobName, adapter, new PrintAttributes.Builder().build());
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "PDF-Export konnte nicht gestartet werden.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void saveTextFile(String fileName, String mimeType, String content) {
            new Thread(() -> {
                try {
                    String safeName = (fileName == null || fileName.trim().isEmpty()) ? "stundenkonto.txt" : fileName;
                    byte[] bytes = (content == null ? "" : content).getBytes(StandardCharsets.UTF_8);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        ContentValues values = new ContentValues();
                        values.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                        values.put(MediaStore.Downloads.MIME_TYPE, mimeType == null ? "text/plain" : mimeType);
                        values.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/Stundenkonto Gruettner");
                        android.net.Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values);
                        if (uri == null) throw new IllegalStateException("Kein Download-Ziel");
                        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                            if (out == null) throw new IllegalStateException("Datei konnte nicht geöffnet werden");
                            out.write(bytes);
                        }
                    } else {
                        File base = new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Stundenkonto Gruettner");
                        if (!base.exists()) base.mkdirs();
                        try (FileOutputStream out = new FileOutputStream(new File(base, safeName))) {
                            out.write(bytes);
                        }
                    }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Gespeichert in Downloads / Stundenkonto Gruettner", Toast.LENGTH_LONG).show());
                } catch (Exception e) {
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Datei konnte nicht gespeichert werden.", Toast.LENGTH_LONG).show());
                }
            }).start();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView == null) { super.onBackPressed(); return; }
        webView.evaluateJavascript(
                "(function(){try{return window.handleAndroidBack?window.handleAndroidBack():'exit'}catch(e){return 'exit'}})();",
                result -> {
                    if (result == null || result.contains("exit")) {
                        if (webView.canGoBack()) webView.goBack(); else MainActivity.super.onBackPressed();
                    }
                }
        );
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.removeJavascriptInterface("Android");
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
