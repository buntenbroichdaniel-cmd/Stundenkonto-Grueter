package de.stundenkonto.grueter;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.Insets;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.FrameLayout;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private View topSystemBar;
    private View bottomSystemBar;

    private static final int FOREST = Color.rgb(8, 73, 64);
    private static final int CREAM = Color.rgb(247, 243, 233);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Android 15/16 erzwingt bei targetSdk 35 Edge-to-Edge.
        // Deshalb reservieren wir die Systemleisten als echte Layout-Flächen,
        // statt nur CSS/Padding zu verwenden. So kann die WebView niemals
        // unter Status- oder Navigationsleiste rutschen.
        getWindow().setStatusBarColor(Color.TRANSPARENT);
        getWindow().setNavigationBarColor(Color.TRANSPARENT);

        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        getWindow().getDecorView().setSystemUiVisibility(flags);

        root = new FrameLayout(this);
        root.setBackgroundColor(CREAM);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(CREAM);
        FrameLayout.LayoutParams webLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT);
        root.addView(webView, webLp);

        topSystemBar = new View(this);
        topSystemBar.setBackgroundColor(FOREST);
        FrameLayout.LayoutParams topLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 0, Gravity.TOP);
        root.addView(topSystemBar, topLp);

        bottomSystemBar = new View(this);
        bottomSystemBar.setBackgroundColor(CREAM);
        FrameLayout.LayoutParams bottomLp = new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, 0, Gravity.BOTTOM);
        root.addView(bottomSystemBar, bottomLp);

        root.setOnApplyWindowInsetsListener((v, insets) -> {
            int top = 0;
            int bottom = 0;
            int left = 0;
            int right = 0;

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Insets safe = insets.getInsets(
                        WindowInsets.Type.statusBars()
                                | WindowInsets.Type.navigationBars()
                                | WindowInsets.Type.displayCutout());
                top = safe.top;
                bottom = safe.bottom;
                left = safe.left;
                right = safe.right;
            } else {
                top = insets.getSystemWindowInsetTop();
                bottom = insets.getSystemWindowInsetBottom();
                left = insets.getSystemWindowInsetLeft();
                right = insets.getSystemWindowInsetRight();
            }

            FrameLayout.LayoutParams wlp = (FrameLayout.LayoutParams) webView.getLayoutParams();
            wlp.setMargins(left, top, right, bottom);
            webView.setLayoutParams(wlp);

            FrameLayout.LayoutParams tlp = (FrameLayout.LayoutParams) topSystemBar.getLayoutParams();
            tlp.height = top;
            topSystemBar.setLayoutParams(tlp);

            FrameLayout.LayoutParams blp = (FrameLayout.LayoutParams) bottomSystemBar.getLayoutParams();
            blp.height = bottom;
            bottomSystemBar.setLayoutParams(blp);

            return insets;
        });
        root.requestApplyInsets();

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        settings.setTextZoom(100);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView == null) {
            super.onBackPressed();
            return;
        }

        webView.evaluateJavascript(
                "(function(){try{return window.handleAndroidBack?window.handleAndroidBack():'exit'}catch(e){return 'exit'}})();",
                result -> {
                    if (result == null || result.contains("exit")) {
                        if (webView.canGoBack()) {
                            webView.goBack();
                        } else {
                            MainActivity.super.onBackPressed();
                        }
                    }
                }
        );
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.stopLoading();
            webView.setWebChromeClient(null);
            webView.setWebViewClient(null);
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
