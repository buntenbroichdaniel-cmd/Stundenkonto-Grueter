package de.stundenkonto.grueter;

import android.Manifest;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Insets;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.speech.RecognizerIntent;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Locale;
import java.util.concurrent.Executor;

public class MainActivity extends FragmentActivity {
    private static final int FILE_CHOOSER_REQUEST = 5011, VOICE_REQUEST = 5012, PAYROLL_REQUEST = 5013, CLOUD_BACKUP_REQUEST = 5014, NOTIFY_PERMISSION = 5015;
    private WebView webView; private FrameLayout root; private View topSystemBar; private FrameLayout lockCover; private ValueCallback<Uri[]> pendingFileCallback;
    private String pendingPayrollMonth, pendingCloudName, pendingCloudContent;
    private static final int FOREST = Color.rgb(8,73,64), CREAM = Color.rgb(247,243,233);
    private SharedPreferences prefs; private long lastAuth=0;

    @Override protected void onCreate(Bundle savedInstanceState){super.onCreate(savedInstanceState);prefs=getSharedPreferences("stundenkonto_native",MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.TRANSPARENT);getWindow().setNavigationBarColor(CREAM);if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.Q)getWindow().setNavigationBarContrastEnforced(false);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE|View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN|View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        root=new FrameLayout(this);root.setBackgroundColor(CREAM);setContentView(root);webView=new WebView(this);webView.setBackgroundColor(CREAM);root.addView(webView,new FrameLayout.LayoutParams(-1,-1));topSystemBar=new View(this);topSystemBar.setBackgroundColor(FOREST);root.addView(topSystemBar,new FrameLayout.LayoutParams(-1,0,Gravity.TOP));createLockCover();if(prefs.getBoolean("app_lock",false))lockAppUI();
        root.setOnApplyWindowInsetsListener((v,insets)->{int top,left,right;if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.R){Insets safe=insets.getInsets(WindowInsets.Type.statusBars()|WindowInsets.Type.navigationBars()|WindowInsets.Type.displayCutout());top=safe.top;left=safe.left;right=safe.right;}else{top=insets.getSystemWindowInsetTop();left=insets.getSystemWindowInsetLeft();right=insets.getSystemWindowInsetRight();}FrameLayout.LayoutParams w=(FrameLayout.LayoutParams)webView.getLayoutParams();w.setMargins(left,top,right,0);webView.setLayoutParams(w);FrameLayout.LayoutParams t=(FrameLayout.LayoutParams)topSystemBar.getLayoutParams();t.height=top;topSystemBar.setLayoutParams(t);return insets;});root.requestApplyInsets();
        WebSettings s=webView.getSettings();s.setJavaScriptEnabled(true);s.setDomStorageEnabled(true);s.setAllowFileAccess(true);s.setAllowContentAccess(true);s.setBuiltInZoomControls(false);s.setDisplayZoomControls(false);s.setTextZoom(100);s.setCacheMode(WebSettings.LOAD_DEFAULT);webView.setOverScrollMode(View.OVER_SCROLL_NEVER);webView.setWebViewClient(new WebViewClient());webView.setWebChromeClient(new WebChromeClient(){@Override public boolean onShowFileChooser(WebView w,ValueCallback<Uri[]> cb,FileChooserParams p){if(pendingFileCallback!=null)pendingFileCallback.onReceiveValue(null);pendingFileCallback=cb;try{startActivityForResult(p.createIntent(),FILE_CHOOSER_REQUEST);return true;}catch(Exception e){pendingFileCallback=null;Toast.makeText(MainActivity.this,"Dateiauswahl konnte nicht geöffnet werden.",Toast.LENGTH_LONG).show();return false;}}});webView.addJavascriptInterface(new AndroidBridge(),"Android");webView.loadUrl("file:///android_asset/index.html");scheduleConfiguredReminders();}

    @Override protected void onResume(){super.onResume();if(prefs.getBoolean("app_lock",false)&&System.currentTimeMillis()-lastAuth>300000){lockAppUI();showBiometricLock();}else if(!prefs.getBoolean("app_lock",false)||System.currentTimeMillis()-lastAuth<=300000){unlockAppUI();}}
    private void createLockCover(){lockCover=new FrameLayout(this);lockCover.setBackgroundColor(FOREST);TextView t=new TextView(this);t.setText("🔒\nStundenkonto Grüttner\n\nZum Entsperren tippen");t.setTextColor(Color.WHITE);t.setTextSize(20);t.setGravity(Gravity.CENTER);t.setPadding(32,32,32,32);lockCover.addView(t,new FrameLayout.LayoutParams(-1,-1));lockCover.setOnClickListener(v->showBiometricLock());lockCover.setVisibility(View.GONE);root.addView(lockCover,new FrameLayout.LayoutParams(-1,-1));}
    private void lockAppUI(){if(webView!=null)webView.setVisibility(View.INVISIBLE);if(lockCover!=null){lockCover.setVisibility(View.VISIBLE);lockCover.bringToFront();}}
    private void unlockAppUI(){if(webView!=null)webView.setVisibility(View.VISIBLE);if(lockCover!=null)lockCover.setVisibility(View.GONE);}
    private void showBiometricLock(){lockAppUI();BiometricManager bm=BiometricManager.from(this);int allowed=BiometricManager.Authenticators.BIOMETRIC_STRONG|BiometricManager.Authenticators.DEVICE_CREDENTIAL;if(bm.canAuthenticate(allowed)!=BiometricManager.BIOMETRIC_SUCCESS){Toast.makeText(this,"Gerätesperre/Biometrie ist nicht eingerichtet.",Toast.LENGTH_LONG).show();return;}Executor ex=ContextCompat.getMainExecutor(this);BiometricPrompt prompt=new BiometricPrompt(this,ex,new BiometricPrompt.AuthenticationCallback(){@Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){super.onAuthenticationSucceeded(r);lastAuth=System.currentTimeMillis();unlockAppUI();}@Override public void onAuthenticationError(int code,CharSequence msg){super.onAuthenticationError(code,msg);lockAppUI();if(code!=BiometricPrompt.ERROR_USER_CANCELED&&code!=BiometricPrompt.ERROR_NEGATIVE_BUTTON)Toast.makeText(MainActivity.this,msg,Toast.LENGTH_SHORT).show();}});prompt.authenticate(new BiometricPrompt.PromptInfo.Builder().setTitle("Stundenkonto entsperren").setSubtitle("Fingerabdruck oder Geräte-PIN verwenden").setAllowedAuthenticators(allowed).build());}

    public class AndroidBridge{
        @JavascriptInterface public void printPage(String jobName){runOnUiThread(()->{try{PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);PrintDocumentAdapter a=webView.createPrintDocumentAdapter(jobName==null?"Stundenkonto":jobName);pm.print(jobName,a,new PrintAttributes.Builder().build());}catch(Exception e){Toast.makeText(MainActivity.this,"PDF-Export konnte nicht gestartet werden.",Toast.LENGTH_LONG).show();}});}
        @JavascriptInterface public void saveTextFile(String fileName,String mimeType,String content){new Thread(()->saveDownload(fileName,mimeType,content)).start();}
        @JavascriptInterface public void startVoiceInput(){runOnUiThread(()->{try{Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.GERMANY.toLanguageTag());i.putExtra(RecognizerIntent.EXTRA_PROMPT,"Arbeitszeit oder Frage sprechen");startActivityForResult(i,VOICE_REQUEST);}catch(Exception e){Toast.makeText(MainActivity.this,"Spracheingabe ist nicht verfügbar.",Toast.LENGTH_LONG).show();}});}
        @JavascriptInterface public void recognizeImage(String dataUrl){if(dataUrl==null)return;new Thread(()->{try{String raw=dataUrl.contains(",")?dataUrl.substring(dataUrl.indexOf(',')+1):dataUrl;byte[] bytes=Base64.decode(raw,Base64.DEFAULT);Bitmap b=BitmapFactory.decodeByteArray(bytes,0,bytes.length);InputImage img=InputImage.fromBitmap(b,0);TextRecognizer r=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);r.process(img).addOnSuccessListener(x->sendOcrResult(x.getText(),null)).addOnFailureListener(e->sendOcrResult("","Text konnte nicht erkannt werden."));}catch(Exception e){sendOcrResult("","Bild konnte nicht analysiert werden.");}}).start();}
        @JavascriptInterface public void setAppLockEnabled(boolean enabled){prefs.edit().putBoolean("app_lock",enabled).apply();runOnUiThread(()->{if(enabled){lastAuth=0;lockAppUI();showBiometricLock();}else{lastAuth=0;unlockAppUI();}});}
        @JavascriptInterface public void updateBackupTimestamp(double ts){prefs.edit().putLong("last_backup",(long)ts).apply();}
        @JavascriptInterface public void configureReminders(String json){try{JSONObject o=new JSONObject(json);prefs.edit().putBoolean("reminders",o.optBoolean("enabled",false)).putString("routine_json",json).apply();if(Build.VERSION.SDK_INT>=33&&o.optBoolean("enabled",false)&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},NOTIFY_PERMISSION);scheduleConfiguredReminders();}catch(Exception ignored){}}
        @JavascriptInterface public void pickPayrollDocument(String month){runOnUiThread(()->{pendingPayrollMonth=month;Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");i.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/pdf","image/*"});startActivityForResult(i,PAYROLL_REQUEST);});}
        @JavascriptInterface public void openDocument(String uri){runOnUiThread(()->{try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(uri));i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(i);}catch(Exception e){Toast.makeText(MainActivity.this,"Dokument konnte nicht geöffnet werden.",Toast.LENGTH_LONG).show();}});}
        @JavascriptInterface public void saveBackupToCloud(String name,String content){runOnUiThread(()->{pendingCloudName=name;pendingCloudContent=content;Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,name);startActivityForResult(i,CLOUD_BACKUP_REQUEST);});}
    }
    private void saveDownload(String fileName,String mimeType,String content){try{byte[] bytes=(content==null?"":content).getBytes(StandardCharsets.UTF_8);if(Build.VERSION.SDK_INT>=29){ContentValues v=new ContentValues();v.put(MediaStore.Downloads.DISPLAY_NAME,fileName);v.put(MediaStore.Downloads.MIME_TYPE,mimeType==null?"text/plain":mimeType);v.put(MediaStore.Downloads.RELATIVE_PATH,Environment.DIRECTORY_DOWNLOADS+"/Stundenkonto Gruettner");Uri u=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,v);try(OutputStream out=getContentResolver().openOutputStream(u)){out.write(bytes);}}else{File base=new File(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS),"Stundenkonto Gruettner");base.mkdirs();try(FileOutputStream out=new FileOutputStream(new File(base,fileName))){out.write(bytes);}}runOnUiThread(()->Toast.makeText(this,"Gespeichert in Downloads / Stundenkonto Gruettner",Toast.LENGTH_LONG).show());}catch(Exception e){runOnUiThread(()->Toast.makeText(this,"Datei konnte nicht gespeichert werden.",Toast.LENGTH_LONG).show());}}
    private void sendOcrResult(String text,String error){runOnUiThread(()->webView.evaluateJavascript("window.onOcrResult&&window.onOcrResult("+JSONObject.quote(text==null?"":text)+","+JSONObject.quote(error==null?"":error)+");",null));}
    private String displayName(Uri uri){try(android.database.Cursor c=getContentResolver().query(uri,new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())return c.getString(0);}catch(Exception ignored){}return "Abrechnung";}
    private void scheduleConfiguredReminders(){boolean enabled=prefs.getBoolean("reminders",false);AlarmManager am=(AlarmManager)getSystemService(ALARM_SERVICE);for(int req:new int[]{702,704,710}){PendingIntent pi=PendingIntent.getBroadcast(this,req,new Intent(this,ReminderReceiver.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.cancel(pi);}if(!enabled)return;try{JSONObject o=new JSONObject(prefs.getString("routine_json","{}"));JSONArray days=o.optJSONArray("days");if(days==null)days=new JSONArray("[2,4]");for(int j=0;j<days.length();j++){int jsDay=days.optInt(j);int calDay=jsDay==0?Calendar.SUNDAY:jsDay+1;Calendar c=Calendar.getInstance();c.set(Calendar.HOUR_OF_DAY,20);c.set(Calendar.MINUTE,30);c.set(Calendar.SECOND,0);while(c.get(Calendar.DAY_OF_WEEK)!=calDay||c.getTimeInMillis()<=System.currentTimeMillis())c.add(Calendar.DAY_OF_YEAR,1);Intent i=new Intent(this,ReminderReceiver.class).putExtra("type","work");PendingIntent pi=PendingIntent.getBroadcast(this,700+jsDay,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.setInexactRepeating(AlarmManager.RTC_WAKEUP,c.getTimeInMillis(),7L*24*60*60*1000,pi);}Calendar m=Calendar.getInstance();m.add(Calendar.MONTH,1);m.set(Calendar.DAY_OF_MONTH,1);m.set(Calendar.HOUR_OF_DAY,10);m.set(Calendar.MINUTE,0);m.set(Calendar.SECOND,0);Intent mi=new Intent(this,ReminderReceiver.class).putExtra("type","month");PendingIntent mpi=PendingIntent.getBroadcast(this,710,mi,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);am.set(AlarmManager.RTC_WAKEUP,m.getTimeInMillis(),mpi);}catch(Exception ignored){}}
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){super.onActivityResult(requestCode,resultCode,data);if(requestCode==FILE_CHOOSER_REQUEST){if(pendingFileCallback!=null){pendingFileCallback.onReceiveValue(resultCode==RESULT_OK?WebChromeClient.FileChooserParams.parseResult(resultCode,data):null);pendingFileCallback=null;}return;}if(requestCode==VOICE_REQUEST&&resultCode==RESULT_OK&&data!=null){ArrayList<String> m=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);if(m!=null&&!m.isEmpty())webView.evaluateJavascript("window.receiveVoiceText&&window.receiveVoiceText("+JSONObject.quote(m.get(0))+");",null);return;}if(requestCode==PAYROLL_REQUEST&&resultCode==RESULT_OK&&data!=null){Uri u=data.getData();if(u!=null){try{getContentResolver().takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}String name=displayName(u),mime=getContentResolver().getType(u);webView.evaluateJavascript("window.onPayrollDocumentPicked&&window.onPayrollDocumentPicked("+JSONObject.quote(pendingPayrollMonth)+","+JSONObject.quote(u.toString())+","+JSONObject.quote(name)+","+JSONObject.quote(mime==null?"":mime)+");",null);}return;}if(requestCode==CLOUD_BACKUP_REQUEST&&resultCode==RESULT_OK&&data!=null&&data.getData()!=null){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){out.write((pendingCloudContent==null?"":pendingCloudContent).getBytes(StandardCharsets.UTF_8));Toast.makeText(this,"Backup am gewählten Speicherort gespeichert.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Cloud-Backup konnte nicht gespeichert werden.",Toast.LENGTH_LONG).show();}pendingCloudContent=null;pendingCloudName=null;}}
    @Override public void onBackPressed(){if(webView==null){super.onBackPressed();return;}webView.evaluateJavascript("(function(){try{return window.handleAndroidBack?window.handleAndroidBack():'exit'}catch(e){return 'exit'}})();",r->{if(r==null||r.contains("exit")){if(webView.canGoBack())webView.goBack();else MainActivity.super.onBackPressed();}});}
    @Override protected void onDestroy(){if(pendingFileCallback!=null)pendingFileCallback.onReceiveValue(null);if(webView!=null){webView.removeJavascriptInterface("Android");webView.stopLoading();webView.setWebChromeClient(null);webView.setWebViewClient(null);webView.destroy();}super.onDestroy();}
}
