
const MONTHS=['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
const key='stundenkontoGrueterV2';
let reportMode='year';

function seed(){return {settings:{hourlyRate:0,limit:603,currentYear:new Date().getFullYear()},months:{},days:[]}}
function legacyClockToMinutes(v){
  if(v===null||v===undefined||v==='') return 0;
  if(typeof v==='string' && v.includes(':')) return parseDuration(v);
  const n=Number(v); if(!Number.isFinite(n)) return 0;
  const sign=n<0?-1:1, a=Math.abs(n), h=Math.floor(a), frac=a-h;
  const hundred=Math.round(frac*100);
  if(hundred>=0 && hundred<60 && Math.abs(frac*100-hundred)<0.01) return sign*(h*60+hundred);
  return Math.round(n*60);
}
function decimalHoursToMinutes(v){const n=Number(v);return Number.isFinite(n)?Math.round(n*60):0}
function parseDuration(v){
  let t=String(v??'').trim().replace(',', '.'); if(!t)return 0;
  let sign=1;if(t.startsWith('-')){sign=-1;t=t.slice(1)}
  if(t.includes(':')){const [h,m='0']=t.split(':');return sign*(Math.max(0,parseInt(h)||0)*60+Math.min(59,Math.max(0,parseInt(m)||0)))}
  if(t.includes('.')){const [h,m='0']=t.split('.');const mm=parseInt((m+'00').slice(0,2))||0;if(mm<60)return sign*((parseInt(h)||0)*60+mm)}
  return sign*((parseInt(t)||0)*60);
}
function duration(mins){
  mins=Math.round(Number(mins)||0);const sign=mins<0?'-':'';mins=Math.abs(mins);const h=Math.floor(mins/60),m=mins%60;return `${sign}${h}:${String(m).padStart(2,'0')} h`;
}
function durationInput(mins){mins=Math.max(0,Math.round(Number(mins)||0));return `${Math.floor(mins/60)}:${String(mins%60).padStart(2,'0')}`}
function fmt(n,d=2){return Number(n||0).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d})}
function euro(n){return fmt(n)+' €'}
function monthKey(y,m){return `${y}-${String(m).padStart(2,'0')}`}
function dayMonthKey(date){return date?date.slice(0,7):''}
function dayMinutes(d){if(Number.isFinite(Number(d?.minutes)))return Math.round(Number(d.minutes));return decimalHoursToMinutes(d?.hours)}

function normalize(raw){
  const d=(raw&&typeof raw==='object')?raw:seed();
  d.settings={...seed().settings,...(d.settings||{})};d.months=d.months&&typeof d.months==='object'?d.months:{};d.days=Array.isArray(d.days)?d.days:[];
  d.days=d.days.map(x=>({...x,minutes:dayMinutes(x)}));
  for(const [k,x0] of Object.entries(d.months)){
    const x=x0||{};const daySum=d.days.filter(q=>dayMonthKey(q.date)===k).reduce((a,q)=>a+dayMinutes(q),0);
    let workedMinutes=Number.isFinite(Number(x.workedMinutes))?Math.round(Number(x.workedMinutes)):0;
    if(!workedMinutes){workedMinutes=(x._daysAuto&&daySum)?daySum:legacyClockToMinutes(x.worked)}
    let paidMinutes=Number.isFinite(Number(x.paidMinutes))?Math.round(Number(x.paidMinutes)):legacyClockToMinutes(x.paidHours);
    d.months[k]={...x,workedMinutes,paidMinutes};
  }
  return d;
}
function load(){try{return normalize(JSON.parse(localStorage.getItem(key))||seed())}catch(e){return seed()}}
let data=load();
function persist(){localStorage.setItem(key,JSON.stringify(data));render()}
function calcMonth(x){const rate=Number(data.settings.hourlyRate)||0;const workedMinutes=Math.round(Number(x.workedMinutes)||0),paidMinutes=Math.round(Number(x.paidMinutes)||0),tips=Number(x.tips)||0;const diffMinutes=workedMinutes-paidMinutes,workedPay=workedMinutes/60*rate,paidSalary=paidMinutes/60*rate;return {...x,workedMinutes,paidMinutes,diffMinutes,workedPay,paidSalary,earnDiff:workedPay-paidSalary,totalPaid:paidSalary+tips}}
function yearMonths(y){return Object.entries(data.months).filter(([k])=>k.startsWith(y+'-')).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,calcMonth(v)])}
function totals(y){let t={workedMinutes:0,paidMinutes:0,diffMinutes:0,workedPay:0,paidSalary:0,earnDiff:0,tips:0,totalPaid:0};yearMonths(y).forEach(([,m])=>Object.keys(t).forEach(k=>t[k]+=Number(m[k]||0)));return t}
function cumulativeBalance(untilKey){let s=0;Object.entries(data.months).sort(([a],[b])=>a.localeCompare(b)).forEach(([k,v])=>{if(!untilKey||k<=untilKey)s+=calcMonth(v).diffMinutes});return s}
function cumulativeOpenMoney(untilKey){return cumulativeBalance(untilKey)/60*(Number(data.settings.hourlyRate)||0)}

let currentView='dashboard',viewHistory=[];
function activateView(id,push=true){if(!document.getElementById(id))return;if(push&&id!==currentView)viewHistory.push(currentView);currentView=id;document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));document.getElementById(id).classList.add('active');document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',(b.getAttribute('onclick')||'').includes("'"+id+"'")));render()}
function showView(id,btn){activateView(id,true)}
function handleAndroidBack(){const open=[...document.querySelectorAll('.modal.show')];if(open.length){open[open.length-1].classList.remove('show');return 'handled'}if(currentView!=='dashboard'){const prev=viewHistory.length?viewHistory.pop():'dashboard';activateView(prev,false);return 'handled'}return 'exit'}window.handleAndroidBack=handleAndroidBack;

function render(){const y=Number(data.settings.currentYear);const t=totals(y);dashBalance.textContent=duration(cumulativeBalance());const openMoney=cumulativeOpenMoney();dashMoneyDiff.textContent=euro(openMoney);dashMoneyDiff.className='big '+(openMoney>0?'money-open':'money-ok');dashEarned.textContent=euro(t.workedPay);dashTips.textContent=euro(t.tips);renderCurrentMonth();renderMonths(y);renderDays();renderReports();renderSettings()}
function renderCurrentMonth(){const now=new Date(),y=Number(data.settings.currentYear),m=now.getMonth()+1,k=monthKey(y,m),x=calcMonth(data.months[k]||{}),limit=Number(data.settings.limit)||603;const pct=limit>0?Math.max(0,Math.min(100,(x.workedPay/limit)*100)):0;currentMonthCard.innerHTML=`<div class="current-head"><div><div class="small">AKTUELLER MONAT</div><div class="current-title">${MONTHS[m-1]} ${y}</div><div class="small" style="margin-top:3px">${duration(x.workedMinutes)} gearbeitet</div></div><div style="text-align:right"><b>${euro(x.workedPay)}</b><div class="small">erarbeitet</div></div></div><div class="limitbar"><i style="width:${pct}%"></i></div><div class="minirow"><span>${fmt(pct,0)} % der Grenze</span><span>${euro(limit)} Grenze</span></div>`}
function renderMonths(y){const arr=yearMonths(y);if(!arr.length){monthList.innerHTML='<div class="card small">Noch keine Monatsdaten vorhanden.</div>';return}monthList.innerHTML=arr.map(([k,m])=>{const mi=Number(k.slice(5))-1,b=cumulativeBalance(k),open=cumulativeOpenMoney(k);return `<div class="month" onclick="openMonth('${k}')"><div class="monthhead"><div><div class="monthtitle">${MONTHS[mi]} ${k.slice(0,4)}</div><div class="small">${m.note||'Keine Notiz'}</div></div><span class="pill">${duration(b)} offen</span></div><div class="summaryline"><div><b>${duration(m.workedMinutes)}</b><span>gearbeitet</span></div><div><b>${euro(m.workedPay)}</b><span>erarbeitet</span></div><div><b>${euro(m.paidSalary)}</b><span>ausgezahlt</span></div><div><b class="${open>0?'money-open':'money-ok'}">${euro(open)}</b><span>Gehalt gesamt offen</span></div></div></div>`}).join('')}
function renderDays(){const arr=data.days.map((d,i)=>({...d,_index:i})).sort((a,b)=>(b.date||'').localeCompare(a.date||''));if(!arr.length){dayList.innerHTML='<div class="card small">Noch keine Arbeitstage erfasst.</div>';return}dayList.innerHTML=arr.map(d=>`<div class="month" onclick="openDay(${d._index})"><div class="monthhead"><div><div class="monthtitle">${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</div><div class="small">${d.start||'–'} bis ${d.end||'–'} · Pause ${d.breakMin||0} Min.</div></div><b>${duration(dayMinutes(d))}</b></div><div class="small" style="margin-top:6px">${d.note||'Antippen zum Bearbeiten'}</div></div>`).join('')}
function setReportMode(mode){reportMode=mode;reportYearTab.classList.toggle('active',mode==='year');reportMonthTab.classList.toggle('active',mode==='month');yearReportPanel.classList.toggle('active',mode==='year');monthReportPanel.classList.toggle('active',mode==='month');renderReports()}
function reportYears(){return [...new Set(Object.keys(data.months).map(k=>k.slice(0,4)).concat(data.days.map(d=>(d.date||'').slice(0,4)).filter(Boolean),[String(data.settings.currentYear)]))].sort()}
function renderReports(){
  const years=reportYears(),current=String(data.settings.currentYear),yVal=reportYear.value||current,myVal=monthReportYear.value||current,mmVal=monthReportMonth.value||String(new Date().getMonth()+1);
  reportYear.innerHTML=years.map(y=>`<option value="${y}" ${y===yVal?'selected':''}>${y}</option>`).join('');monthReportYear.innerHTML=years.map(y=>`<option value="${y}" ${y===myVal?'selected':''}>${y}</option>`).join('');monthReportMonth.innerHTML=MONTHS.map((m,i)=>`<option value="${i+1}" ${String(i+1)===String(mmVal)?'selected':''}>${m}</option>`).join('');
  const t=totals(Number(reportYear.value||yVal));reportBox.innerHTML=`<div class="summaryline"><div><b>${duration(t.workedMinutes)}</b><span>gearbeitet</span></div><div><b>${duration(t.paidMinutes)}</b><span>ausgezahlte Zeit</span></div><div><b class="${t.diffMinutes>0?'money-open':'money-ok'}">${duration(t.diffMinutes)}</b><span>offene Zeit</span></div><div><b>${euro(t.workedPay)}</b><span>erarbeitet</span></div><div><b>${euro(t.paidSalary)}</b><span>Gehalt ausgezahlt</span></div><div><b class="${t.earnDiff>0?'money-open':'money-ok'}">${euro(t.earnDiff)}</b><span>im Jahr offen</span></div><div><b>${euro(t.tips)}</b><span>Trinkgeld</span></div><div><b>${euro(t.totalPaid)}</b><span>Auszahlung gesamt</span></div></div>`;
  const y=Number(monthReportYear.value||myVal),m=Number(monthReportMonth.value||mmVal),k=monthKey(y,m),x=calcMonth(data.months[k]||{}),days=data.days.filter(d=>dayMonthKey(d.date)===k).slice().sort((a,b)=>a.date.localeCompare(b.date)),avg=days.length?Math.round(days.reduce((sum,d)=>sum+dayMinutes(d),0)/days.length):0;
  monthReportBox.innerHTML=`<div class="summaryline"><div><b>${duration(x.workedMinutes)}</b><span>gearbeitet</span></div><div><b>${duration(x.paidMinutes)}</b><span>ausgezahlte Zeit</span></div><div><b class="${x.diffMinutes>0?'money-open':'money-ok'}">${duration(x.diffMinutes)}</b><span>offene Zeit</span></div><div><b>${euro(x.workedPay)}</b><span>erarbeitet</span></div><div><b>${euro(x.paidSalary)}</b><span>Gehalt ausgezahlt</span></div><div><b class="${x.earnDiff>0?'money-open':'money-ok'}">${euro(x.earnDiff)}</b><span>offenes Gehalt</span></div><div><b>${euro(x.tips)}</b><span>Trinkgeld</span></div><div><b>${days.length}</b><span>Arbeitstage</span></div><div><b>${duration(avg)}</b><span>Ø pro Arbeitstag</span></div><div><b>${euro(x.totalPaid)}</b><span>Auszahlung gesamt</span></div></div>${x.note?`<div class="report-note"><b>Monatsnotiz:</b> ${x.note}</div>`:''}`;
  monthReportDays.innerHTML=days.length?`<h3 style="margin:0 0 4px">Arbeitstage im Monat</h3>`+days.map(d=>`<div class="report-day"><div><b>${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</b><br><span>${d.start||'–'} bis ${d.end||'–'} · Pause ${d.breakMin||0} Min.${d.note?' · '+d.note:''}</span></div><b>${duration(dayMinutes(d))}</b></div>`).join(''):`<div class="report-note">Für ${MONTHS[m-1]} ${y} sind keine einzelnen Arbeitstage erfasst.</div>`;
  reportExportBtn.textContent=reportMode==='month'?'Monatsbericht als CSV':'Jahresbericht als CSV';
}
function renderSettings(){hourlyRate.value=data.settings.hourlyRate;limit.value=data.settings.limit;currentYear.value=data.settings.currentYear}
function openMonth(k=''){const now=new Date();mMonth.innerHTML=MONTHS.map((x,i)=>`<option value="${i+1}">${x}</option>`).join('');if(k){const x=calcMonth(data.months[k]||{});mYear.value=k.slice(0,4);mMonth.value=Number(k.slice(5));mWorked.value=durationInput(x.workedMinutes);mPaidHours.value=durationInput(x.paidMinutes);mTips.value=x.tips||0;mNote.value=x.note||''}else{mYear.value=data.settings.currentYear;mMonth.value=now.getMonth()+1;mWorked.value='';mPaidHours.value='';mTips.value='';mNote.value=''}monthModal.dataset.edit=k;monthModal.classList.add('show');updateLiveCalc()}
function saveMonth(){const y=Number(mYear.value),m=Number(mMonth.value);if(!y||!m)return;const k=monthKey(y,m);data.months[k]={workedMinutes:parseDuration(mWorked.value),paidMinutes:parseDuration(mPaidHours.value),tips:Number(mTips.value)||0,note:mNote.value.trim(),_daysAuto:false};closeModal('monthModal');persist()}
function updateLiveCalc(){const rate=Number(data.settings.hourlyRate)||0,w=parseDuration(mWorked.value),p=parseDuration(mPaidHours.value),earned=w/60*rate,paid=p/60*rate;liveEarned.textContent=euro(earned);livePaid.textContent=euro(paid);liveOpen.textContent=euro(earned-paid);liveOpen.className=earned-paid>0?'money-open':'money-ok'}
function syncMonthFromDays(k){if(!k)return;const sum=data.days.filter(d=>dayMonthKey(d.date)===k).reduce((a,d)=>a+dayMinutes(d),0);const existing=data.months[k]||{paidMinutes:0,tips:0,note:''};data.months[k]={...existing,workedMinutes:sum,_daysAuto:true}}
function calcDayMinutes(){if(!dStart.value||!dEnd.value)return 0;const [sh,sm]=dStart.value.split(':').map(Number),[eh,em]=dEnd.value.split(':').map(Number);let mins=(eh*60+em)-(sh*60+sm);if(mins<0)mins+=1440;mins-=Number(dBreak.value||0);return Math.max(0,Math.round(mins))}
function updateDayPreview(){if(dayDurationPreview)dayDurationPreview.innerHTML=`<b>Arbeitszeit:</b> ${duration(calcDayMinutes())}`}
function openDay(index=''){if(index!==''&&data.days[index]){const d=data.days[index];dDate.value=d.date||'';dStart.value=d.start||'';dEnd.value=d.end||'';dBreak.value=d.breakMin||0;dNote.value=d.note||'';dayModal.dataset.edit=String(index);deleteDayBtn.style.display='block'}else{dDate.value=new Date().toISOString().slice(0,10);dStart.value='15:00';dEnd.value='';dBreak.value=0;dNote.value='';dayModal.dataset.edit='';deleteDayBtn.style.display='none'}dayModal.classList.add('show');updateDayPreview()}
function saveDay(){if(!dDate.value)return;const item={date:dDate.value,start:dStart.value,end:dEnd.value,breakMin:Number(dBreak.value)||0,minutes:calcDayMinutes(),note:dNote.value.trim()};const edit=dayModal.dataset.edit;let oldKey='';if(edit!==''&&data.days[Number(edit)]){oldKey=dayMonthKey(data.days[Number(edit)].date);data.days[Number(edit)]=item}else data.days.push(item);const newKey=dayMonthKey(item.date);syncMonthFromDays(newKey);if(oldKey&&oldKey!==newKey)syncMonthFromDays(oldKey);closeModal('dayModal');persist()}
function deleteDay(){const edit=dayModal.dataset.edit;if(edit==='')return;const i=Number(edit);if(!data.days[i]||!confirm('Diesen Arbeitstag wirklich löschen?'))return;const oldKey=dayMonthKey(data.days[i].date);data.days.splice(i,1);syncMonthFromDays(oldKey);closeModal('dayModal');persist()}
function closeModal(id){document.getElementById(id)?.classList.remove('show')}
function saveSettings(){data.settings.hourlyRate=Number(hourlyRate.value)||0;data.settings.limit=Number(limit.value)||603;data.settings.currentYear=Number(currentYear.value)||new Date().getFullYear();persist()}
function download(name,text,type){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),500)}
function exportBackup(){download(`stundenkonto-backup-${Date.now()}.json`,JSON.stringify(data,null,2),'application/json')}
function importBackup(file){if(!file)return;const r=new FileReader();r.onload=()=>{try{const x=normalize(JSON.parse(r.result));data=x;persist();alert('Backup importiert.')}catch(e){alert('Ungültige Backup-Datei.')}};r.readAsText(file)}
function csvText(rows){return rows.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(';')).join('\n')}
function exportReportCSV(){if(reportMode==='month'){const y=Number(monthReportYear.value||data.settings.currentYear),m=Number(monthReportMonth.value||new Date().getMonth()+1),k=monthKey(y,m),x=calcMonth(data.months[k]||{}),days=data.days.filter(d=>dayMonthKey(d.date)===k).slice().sort((a,b)=>a.date.localeCompare(b.date));let rows=[['Monatsbericht',`${MONTHS[m-1]} ${y}`],[],['Gearbeitete Zeit',durationInput(x.workedMinutes)],['Ausgezahlte Zeit',durationInput(x.paidMinutes)],['Offene Zeit',durationInput(x.diffMinutes)],['Erarbeiteter Verdienst',x.workedPay],['Ausgezahltes Gehalt',x.paidSalary],['Offenes Gehalt',x.earnDiff],['Trinkgeld',x.tips],['Gesamtauszahlung',x.totalPaid],['Arbeitstage',days.length],[],['Datum','Beginn','Ende','Pause Min.','Arbeitszeit','Notiz']];days.forEach(d=>rows.push([d.date,d.start||'',d.end||'',d.breakMin||0,durationInput(dayMinutes(d)),d.note||'']));download(`Stundenkonto_${y}_${String(m).padStart(2,'0')}.csv`,csvText(rows),'text/csv;charset=utf-8')}else{const y=Number(reportYear.value||data.settings.currentYear);let rows=[['Monat','Gearbeitete Zeit','Ausgezahlte Zeit','Offene Zeit','Erarbeiteter Verdienst','Ausgezahltes Gehalt','Offenes Gehalt','Trinkgeld','Gesamtauszahlung','Notiz']];yearMonths(y).forEach(([k,m])=>rows.push([MONTHS[Number(k.slice(5))-1],durationInput(m.workedMinutes),durationInput(m.paidMinutes),durationInput(m.diffMinutes),m.workedPay,m.paidSalary,m.earnDiff,m.tips,m.totalPaid,m.note||'']));download(`Stundenkonto_${y}.csv`,csvText(rows),'text/csv;charset=utf-8')}}
function resetAll(){if(confirm('Wirklich alle Daten auf diesem Gerät löschen?')){data=seed();persist()}}

window.addEventListener('load',()=>{
  try{if('serviceWorker' in navigator)navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister())).catch(()=>{});if('caches' in window)caches.keys().then(ks=>ks.forEach(k=>caches.delete(k))).catch(()=>{})}catch(e){}
  mWorked.addEventListener('input',updateLiveCalc);mPaidHours.addEventListener('input',updateLiveCalc);dStart.addEventListener('input',updateDayPreview);dEnd.addEventListener('input',updateDayPreview);dBreak.addEventListener('input',updateDayPreview);persist();
});
