const MONTHS=['Januar','Februar','März','April','Mai','Juni','Juli','August','September','Oktober','November','Dezember'];
const key='stundenkontoGrueterV2';
let reportMode='year';
let currentView='dashboard',viewHistory=[];
const $=id=>document.getElementById(id);

function seed(){return {backupVersion:2,appVersion:'6.1.0',createdAt:new Date().toISOString(),settings:{hourlyRate:0,limit:603,currentYear:new Date().getFullYear(),rateHistory:{},limitHistory:{},lastBackupAt:0},months:{},days:[],payments:[]}}
function actualCurrentKey(){const n=new Date();return monthKey(n.getFullYear(),n.getMonth()+1)}
function monthKey(y,m){return `${y}-${String(m).padStart(2,'0')}`}
function dayMonthKey(date){return date?date.slice(0,7):''}
function legacyClockToMinutes(v){if(v===null||v===undefined||v==='')return 0;if(typeof v==='string'&&v.includes(':'))return parseDuration(v);const n=Number(v);if(!Number.isFinite(n))return 0;const sign=n<0?-1:1,a=Math.abs(n),h=Math.floor(a),frac=a-h,hundred=Math.round(frac*100);if(hundred>=0&&hundred<60&&Math.abs(frac*100-hundred)<.01)return sign*(h*60+hundred);return Math.round(n*60)}
function decimalHoursToMinutes(v){const n=Number(v);return Number.isFinite(n)?Math.round(n*60):0}
function parseDuration(v){let t=String(v??'').trim().replace(',','.');if(!t)return 0;let sign=1;if(t.startsWith('-')){sign=-1;t=t.slice(1)}if(t.includes(':')){const [h,m='0']=t.split(':');return sign*((parseInt(h)||0)*60+Math.min(59,Math.max(0,parseInt(m)||0)))}if(t.includes('.')){const [h,m='0']=t.split('.');const mm=parseInt((m+'00').slice(0,2))||0;if(mm<60)return sign*((parseInt(h)||0)*60+mm)}return sign*((parseInt(t)||0)*60)}
function duration(mins){mins=Math.round(Number(mins)||0);const sign=mins<0?'-':'';mins=Math.abs(mins);return `${sign}${Math.floor(mins/60)}:${String(mins%60).padStart(2,'0')} h`}
function signedDuration(mins){mins=Math.round(Number(mins)||0);if(mins===0)return '0:00 h';return `${mins>0?'+':'-'}${duration(Math.abs(mins))}`}
function durationInput(mins){mins=Math.max(0,Math.round(Number(mins)||0));return `${Math.floor(mins/60)}:${String(mins%60).padStart(2,'0')}`}
function fmt(n,d=2){return Number(n||0).toLocaleString('de-DE',{minimumFractionDigits:d,maximumFractionDigits:d})}
function euro(n){return fmt(n)+' €'}
function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function dayMinutes(d){if(Number.isFinite(Number(d?.minutes)))return Math.round(Number(d.minutes));return decimalHoursToMinutes(d?.hours)}

function normalize(raw){
  const d=(raw&&typeof raw==='object')?raw:seed();
  d.settings={...seed().settings,...(d.settings||{})};
  d.settings.rateHistory=(d.settings.rateHistory&&typeof d.settings.rateHistory==='object')?d.settings.rateHistory:{};
  d.settings.limitHistory=(d.settings.limitHistory&&typeof d.settings.limitHistory==='object')?d.settings.limitHistory:{};
  if(!Object.keys(d.settings.rateHistory).length&&Number(d.settings.hourlyRate))d.settings.rateHistory['0000-01']=Number(d.settings.hourlyRate);
  if(!Object.keys(d.settings.limitHistory).length&&Number(d.settings.limit))d.settings.limitHistory['0000-01']=Number(d.settings.limit);
  d.months=d.months&&typeof d.months==='object'?d.months:{};d.days=Array.isArray(d.days)?d.days:[];d.payments=Array.isArray(d.payments)?d.payments:[];
  d.days=d.days.map(x=>({...x,minutes:dayMinutes(x)}));
  d.payments=d.payments.map(p=>({...p,hoursMinutes:Number.isFinite(Number(p.hoursMinutes))?Math.round(Number(p.hoursMinutes)):parseDuration(p.hours||''),amount:Number(p.amount)||0}));
  for(const [k,x0] of Object.entries(d.months)){
    const x=x0||{},daySum=d.days.filter(q=>dayMonthKey(q.date)===k).reduce((a,q)=>a+dayMinutes(q),0);
    let workedMinutes=Number.isFinite(Number(x.workedMinutes))?Math.round(Number(x.workedMinutes)):0;if(!workedMinutes)workedMinutes=(x._daysAuto&&daySum)?daySum:legacyClockToMinutes(x.worked);
    let paidMinutes=Number.isFinite(Number(x.paidMinutes))?Math.round(Number(x.paidMinutes)):legacyClockToMinutes(x.paidHours);
    let officialMinutes=Number.isFinite(Number(x.officialMinutes))?Math.round(Number(x.officialMinutes)):legacyClockToMinutes(x.officialHours);
    const booked=d.payments.filter(p=>p.month===k).reduce((a,p)=>a+Number(p.hoursMinutes||0),0);if(booked>0)paidMinutes=booked;
    d.months[k]={...x,workedMinutes,paidMinutes,officialMinutes};
  }
  d.backupVersion=Number(d.backupVersion)||1;d.appVersion=d.appVersion||'legacy';return d;
}
function load(){try{return normalize(JSON.parse(localStorage.getItem(key))||seed())}catch(e){return seed()}}
let data=load();
function persist(){localStorage.setItem(key,JSON.stringify(data));render()}

function historyValue(hist,k,fallback){const keys=Object.keys(hist||{}).filter(x=>x<=k).sort();return keys.length?Number(hist[keys[keys.length-1]])||0:Number(fallback)||0}
function rateFor(k){return historyValue(data.settings.rateHistory,k,data.settings.hourlyRate)}
function limitFor(k){return historyValue(data.settings.limitHistory,k,data.settings.limit||603)}
function paymentsFor(k){return data.payments.filter(p=>p.month===k).sort((a,b)=>(b.date||'').localeCompare(a.date||''))}
function calcMonth(k,x=data.months[k]||{}){const rate=rateFor(k),workedMinutes=Math.round(Number(x.workedMinutes)||0),paidMinutes=Math.round(Number(x.paidMinutes)||0),officialMinutes=Math.round(Number(x.officialMinutes)||0),tips=Number(x.tips)||0,diffMinutes=workedMinutes-paidMinutes,workedPay=workedMinutes/60*rate,paidSalary=paidMinutes/60*rate,officialDiff=officialMinutes?workedMinutes-officialMinutes:null,actualPaidAmount=paymentsFor(k).reduce((a,p)=>a+Number(p.amount||0),0);return {...x,key:k,rate,limit:limitFor(k),workedMinutes,paidMinutes,officialMinutes,diffMinutes,workedPay,paidSalary,earnDiff:workedPay-paidSalary,totalPaid:paidSalary+tips,officialDiff,actualPaidAmount}}
function yearMonths(y){return Object.entries(data.months).filter(([k])=>k.startsWith(y+'-')).sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>[k,calcMonth(k,v)])}
function totals(y){let t={workedMinutes:0,paidMinutes:0,diffMinutes:0,workedPay:0,paidSalary:0,earnDiff:0,tips:0,totalPaid:0};yearMonths(y).forEach(([,m])=>Object.keys(t).forEach(k=>t[k]+=Number(m[k]||0)));return t}
function closedMonths(){const ck=actualCurrentKey();return Object.entries(data.months).filter(([k])=>k<ck).map(([k,v])=>[k,calcMonth(k,v)])}
function closedBalance(){return closedMonths().reduce((s,[,m])=>s+m.diffMinutes,0)}
function closedOpenMoney(){return closedMonths().reduce((s,[,m])=>s+m.earnDiff,0)}
function balanceBefore(k){return Object.entries(data.months).filter(([mk])=>mk<k).reduce((s,[mk,v])=>s+calcMonth(mk,v).diffMinutes,0)}
function moneyBefore(k){return Object.entries(data.months).filter(([mk])=>mk<k).reduce((s,[mk,v])=>s+calcMonth(mk,v).earnDiff,0)}
function monthDays(k){return data.days.filter(d=>dayMonthKey(d.date)===k)}
function avgDay(k){const ds=monthDays(k);return ds.length?Math.round(ds.reduce((s,d)=>s+dayMinutes(d),0)/ds.length):0}
function isClosed(k){return k<actualCurrentKey()}

function activateView(id,push=true){if(!$(id))return;if(push&&id!==currentView)viewHistory.push(currentView);currentView=id;document.querySelectorAll('.view').forEach(v=>v.classList.remove('active'));$(id).classList.add('active');document.querySelectorAll('.navbtn').forEach(b=>b.classList.toggle('active',(b.getAttribute('onclick')||'').includes("'"+id+"'")));render()}
function showView(id){activateView(id,true)}
function handleAndroidBack(){const open=[...document.querySelectorAll('.modal.show')];if(open.length){open[open.length-1].classList.remove('show');return 'handled'}if(currentView!=='dashboard'){activateView(viewHistory.length?viewHistory.pop():'dashboard',false);return 'handled'}return 'exit'}window.handleAndroidBack=handleAndroidBack;

function render(){
  const y=Number(data.settings.currentYear),t=totals(y),b=closedBalance(),openMoney=closedOpenMoney();
  $('dashBalance').textContent=signedDuration(b);$('dashBalance').className='big '+(b>=0?'positive':'negative');
  $('dashMoneyDiff').textContent=(openMoney>0?'+':'')+euro(openMoney);$('dashMoneyDiff').className='big '+(openMoney>0?'money-open':'money-ok');
  $('dashEarned').textContent=euro(t.workedPay);$('dashEarned').previousElementSibling.textContent=`Erarbeitet ${y}`;$('dashTips').textContent=euro(t.tips);
  renderCurrentMonth();renderMonths(y);renderDays();renderReports();renderSettings();renderBackupStatus();renderAssistant();
}
function renderCurrentMonth(){
  const k=actualCurrentKey(),[y,m]=k.split('-').map(Number),x=calcMonth(k),limit=x.limit||603,pct=limit>0?Math.max(0,Math.min(100,x.workedPay/limit*100)):0,remaining=Math.max(0,limit-x.workedPay),remainingMinutes=x.rate>0?Math.floor(remaining/x.rate*60):0,avg=avgDay(k),shifts=avg>0?Math.floor(remainingMinutes/avg):0;
  $('currentMonthCard').innerHTML=`<div class="current-head"><div><div class="small">AKTUELLER MONAT</div><div class="current-title">${MONTHS[m-1]} ${y}</div><div class="small" style="margin-top:3px">${duration(x.workedMinutes)} gearbeitet · ${monthDays(k).length} Einsätze</div></div><div style="text-align:right"><b>${euro(x.workedPay)}</b><div class="small">erarbeitet</div></div></div><div class="limitbar"><i style="width:${pct}%"></i></div><div class="minirow"><span>${euro(x.workedPay)} von ${euro(limit)}</span><span>${fmt(pct,0)} %</span></div><div class="current-extra"><div><b>${euro(remaining)}</b><span>noch bis zur Grenze</span></div><div><b>${duration(remainingMinutes)}</b><span>noch mögliche Arbeitszeit</span></div><div><b>${avg?duration(avg):'–'}</b><span>Ø je Arbeitstag</span></div><div><b>${avg?`ca. ${shifts}`:'–'}</b><span>volle Einsätze möglich</span></div></div>`;
  const b=closedBalance(),money=closedOpenMoney();$('closedAccountStrip').innerHTML=`<div><b>Stundenkonto aus Vormonaten</b><br><span>${b>0?'Guthaben beim Arbeitgeber':b<0?'Überzahlung / Minussaldo':'aktuell ausgeglichen'}</span></div><div style="text-align:right"><b class="${b>=0?'positive':'negative'}">${signedDuration(b)}</b><br><span>${money>0?'+':''}${euro(money)}</span></div>`;
}
function monthChecklist(k,m){const ds=monthDays(k).length>0,official=m.officialMinutes>0,paid=m.paidMinutes>0||paymentsFor(k).length>0;return {ds,official,paid,done:[ds,official,paid].filter(Boolean).length}}
function renderMonths(y){
  const ck=actualCurrentKey(),arr=yearMonths(y).filter(([k])=>k!==ck&&k<ck).slice().reverse();if(!arr.length){$('monthList').innerHTML='<div class="card small">Noch keine abgeschlossenen Monate vorhanden.</div>';return}
  $('monthList').innerHTML=arr.map(([k,m])=>{const mi=Number(k.slice(5))-1,c=monthChecklist(k,m),diff=m.diffMinutes,officialText=m.officialDiff===null?'Arbeitgeberzeit fehlt':m.officialDiff===0?'Arbeitgeber stimmt':`${signedDuration(m.officialDiff)} Abweichung`,pill=diff>0?`+${duration(diff)} Guthaben`:diff<0?`${duration(diff)} Überzahlung`:'ausgeglichen';return `<div class="month" onclick="openMonth('${k}')"><div class="monthhead"><div><div class="monthtitle">${MONTHS[mi]} ${k.slice(0,4)}</div><div class="small">${esc(m.note||officialText)}</div></div><span class="pill ${diff<0?'bad':''}">${pill}</span></div><div class="summaryline"><div><b>${duration(m.workedMinutes)}</b><span>eigene Arbeitszeit</span></div><div><b>${m.officialMinutes?duration(m.officialMinutes):'–'}</b><span>Arbeitgeber</span></div><div><b>${euro(m.paidSalary)}</b><span>rechnerisch ausgezahlt</span></div><div><b class="${m.earnDiff>0?'money-open':'money-ok'}">${m.earnDiff>0?'+':''}${euro(m.earnDiff)}</b><span>aus diesem Monat offen</span></div></div><div class="small" style="margin-top:9px">Monatscheck: ${c.done}/3 · ${c.ds?'✓':'○'} Tage · ${c.official?'✓':'○'} Arbeitgeber · ${c.paid?'✓':'○'} Auszahlung</div></div>`}).join('');
}
function renderDays(){const arr=data.days.map((d,i)=>({...d,_index:i})).sort((a,b)=>(b.date||'').localeCompare(a.date||''));if(!arr.length){$('dayList').innerHTML='<div class="card small">Noch keine Arbeitstage erfasst.</div>';return}$('dayList').innerHTML=arr.map(d=>`<div class="month" onclick="openDay(${d._index})"><div class="monthhead"><div><div class="monthtitle">${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</div><div class="small">${d.start||'–'} bis ${d.end||'–'} · Pause ${d.breakMin||0} Min.</div></div><b>${duration(dayMinutes(d))}</b></div><div class="small" style="margin-top:6px">${esc(d.note||'Antippen zum Bearbeiten')}</div></div>`).join('')}

function setReportMode(mode){reportMode=mode;$('reportYearTab').classList.toggle('active',mode==='year');$('reportMonthTab').classList.toggle('active',mode==='month');$('yearReportPanel').classList.toggle('active',mode==='year');$('monthReportPanel').classList.toggle('active',mode==='month');renderReports()}
function reportYears(){return [...new Set(Object.keys(data.months).map(k=>k.slice(0,4)).concat(data.days.map(d=>(d.date||'').slice(0,4)).filter(Boolean),[String(data.settings.currentYear)]))].sort()}
function employerCompareHtml(k,x){if(!x.officialMinutes)return '<div class="report-note">Arbeitgeber-Zeit noch nicht eingetragen.</div>';const d=x.officialDiff;return `<div class="compare-box"><div class="compare-line"><span>Eigene Erfassung</span><b>${duration(x.workedMinutes)}</b></div><div class="compare-line"><span>Arbeitgeber</span><b>${duration(x.officialMinutes)}</b></div><div class="compare-line"><span>Differenz</span><b class="${d===0?'positive':'negative'}">${signedDuration(d)} ${d===0?'✓':''}</b></div>${d>0?'<div class="small">Du hast mehr erfasst als der Arbeitgeber. Diese Zeit sollte geprüft werden.</div>':d<0?'<div class="small">Der Arbeitgeber hat mehr Zeit erfasst als du.</div>':'<div class="small">Die Zeiten stimmen exakt überein.</div>'}</div>`}
function monthCheckHtml(k,x){if(!isClosed(k))return '<div class="report-note">Der Monat läuft noch. Ein endgültiger Saldo entsteht erst nach Monatsende.</div>';const c=monthChecklist(k,x);return `<div class="status-card"><b>Monatsabschluss-Check · ${c.done}/3 erledigt</b><div class="status-grid"><div class="status-item"><b>${c.ds?'✓':'○'} Arbeitstage</b><span>${c.ds?'erfasst':'noch prüfen'}</span></div><div class="status-item"><b>${c.official?'✓':'○'} Arbeitgeberzeit</b><span>${c.official?'eingetragen':'fehlt'}</span></div><div class="status-item"><b>${c.paid?'✓':'○'} Auszahlung</b><span>${c.paid?'erfasst':'noch offen'}</span></div><div class="status-item"><b>${x.diffMinutes>0?'+':''}${duration(x.diffMinutes)}</b><span>Monatssaldo</span></div></div></div>`}
function renderReports(){
  const years=reportYears(),current=String(data.settings.currentYear),yVal=$('reportYear').value||current,myVal=$('monthReportYear').value||current,mmVal=$('monthReportMonth').value||String(new Date().getMonth()+1);
  $('reportYear').innerHTML=years.map(y=>`<option value="${y}" ${y===yVal?'selected':''}>${y}</option>`).join('');$('monthReportYear').innerHTML=years.map(y=>`<option value="${y}" ${y===myVal?'selected':''}>${y}</option>`).join('');$('monthReportMonth').innerHTML=MONTHS.map((m,i)=>`<option value="${i+1}" ${String(i+1)===String(mmVal)?'selected':''}>${m}</option>`).join('');
  const t=totals(Number($('reportYear').value||yVal));$('reportBox').innerHTML=`<div class="summaryline"><div><b>${duration(t.workedMinutes)}</b><span>gearbeitet</span></div><div><b>${duration(t.paidMinutes)}</b><span>ausgezahlte Zeit</span></div><div><b class="${t.diffMinutes>0?'money-open':'money-ok'}">${signedDuration(t.diffMinutes)}</b><span>Jahressaldo</span></div><div><b>${euro(t.workedPay)}</b><span>erarbeitet</span></div><div><b>${euro(t.paidSalary)}</b><span>Gehalt rechnerisch</span></div><div><b class="${t.earnDiff>0?'money-open':'money-ok'}">${euro(t.earnDiff)}</b><span>rechnerisch offen</span></div><div><b>${euro(t.tips)}</b><span>Trinkgeld</span></div><div><b>${euro(t.totalPaid)}</b><span>inkl. Trinkgeld</span></div></div>`;
  const y=Number($('monthReportYear').value||myVal),m=Number($('monthReportMonth').value||mmVal),k=monthKey(y,m),x=calcMonth(k),days=monthDays(k).slice().sort((a,b)=>a.date.localeCompare(b.date)),avg=avgDay(k),pays=paymentsFor(k);
  $('monthReportBox').innerHTML=`<div class="summaryline"><div><b>${duration(x.workedMinutes)}</b><span>eigene Arbeitszeit</span></div><div><b>${x.officialMinutes?duration(x.officialMinutes):'–'}</b><span>Arbeitgeber-Zeit</span></div><div><b>${duration(x.paidMinutes)}</b><span>ausgezahlte Zeit</span></div><div><b>${euro(x.workedPay)}</b><span>erarbeitet</span></div><div><b>${euro(x.paidSalary)}</b><span>rechnerisch ausgezahlt</span></div><div><b class="${x.earnDiff>0?'money-open':'money-ok'}">${euro(x.earnDiff)}</b><span>offenes Gehalt</span></div><div><b>${euro(x.tips)}</b><span>Trinkgeld</span></div><div><b>${days.length}</b><span>Arbeitstage</span></div><div><b>${avg?duration(avg):'–'}</b><span>Ø pro Arbeitstag</span></div><div><b>${euro(x.rate)}</b><span>Stundenlohn</span></div></div>${employerCompareHtml(k,x)}${monthCheckHtml(k,x)}${pays.length?`<div class="report-note"><b>Gebuchte Auszahlungen:</b><br>${pays.map(p=>`${new Date(p.date+'T12:00:00').toLocaleDateString('de-DE')}: ${duration(p.hoursMinutes)} · ${euro(p.amount)}${p.note?' · '+esc(p.note):''}`).join('<br>')}</div>`:''}${x.note?`<div class="report-note"><b>Monatsnotiz:</b> ${esc(x.note)}</div>`:''}`;
  $('monthReportDays').innerHTML=days.length?`<h3 style="margin:0 0 4px">Arbeitstage im Monat</h3>`+days.map(d=>`<div class="report-day"><div><b>${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</b><br><span>${d.start||'–'} bis ${d.end||'–'} · Pause ${d.breakMin||0} Min.${d.note?' · '+esc(d.note):''}</span></div><b>${duration(dayMinutes(d))}</b></div>`).join(''):`<div class="report-note">Für ${MONTHS[m-1]} ${y} sind keine einzelnen Arbeitstage erfasst.</div>`;
  $('reportExportBtn').textContent=reportMode==='month'?'Monatsbericht als CSV':'Jahresbericht als CSV';$('reportPdfBtn').textContent=reportMode==='month'?'Monatsbericht als PDF':'Jahresbericht als PDF';
}

function renderSettings(){$('hourlyRate').value=data.settings.hourlyRate;$('limit').value=data.settings.limit;$('currentYear').value=data.settings.currentYear;const rh=Object.entries(data.settings.rateHistory||{}).filter(([k])=>k!=='0000-01').sort().reverse(),lh=Object.entries(data.settings.limitHistory||{}).filter(([k])=>k!=='0000-01').sort().reverse();$('historyInfo').innerHTML=`<b>Historie</b><br>Stundenlohn: ${rh.length?rh.slice(0,3).map(([k,v])=>`${k}: ${euro(v)}`).join(' · '):'Basiswert gilt für bestehende Monate'}<br>Grenze: ${lh.length?lh.slice(0,3).map(([k,v])=>`${k}: ${euro(v)}`).join(' · '):'Basiswert gilt für bestehende Monate'}`;if($('dataStatus'))$('dataStatus').innerHTML=`<b>Gespeicherte Daten</b><br>${Object.keys(data.months).length} Monate · ${data.days.length} Arbeitstage · ${data.payments.length} Auszahlungen`}
function renderBackupStatus(){const ts=Number(data.settings.lastBackupAt)||0,age=ts?Math.floor((Date.now()-ts)/86400000):9999,text=ts?`Letztes Backup: ${new Date(ts).toLocaleDateString('de-DE')} (${age} Tage)`:'Noch kein Backup erstellt.',warn=age>=30||!ts;const html=`<div class="report-note ${warn?'warning':''}">${warn?'⚠ ': '✓ '}${text}${warn?' · Eine Sicherung wird empfohlen.':''}</div>`;$('backupReminder').innerHTML=html;$('settingsBackupStatus').innerHTML=html}

function openMonth(k=''){const now=new Date();$('mMonth').innerHTML=MONTHS.map((x,i)=>`<option value="${i+1}">${x}</option>`).join('');if(k){const x=calcMonth(k);$('mYear').value=k.slice(0,4);$('mMonth').value=Number(k.slice(5));$('mWorked').value=durationInput(x.workedMinutes);$('mOfficialHours').value=x.officialMinutes?durationInput(x.officialMinutes):'';$('mPaidHours').value=durationInput(x.paidMinutes);$('mTips').value=x.tips||0;$('mNote').value=x.note||''}else{$('mYear').value=data.settings.currentYear;$('mMonth').value=now.getMonth()+1;$('mWorked').value='';$('mOfficialHours').value='';$('mPaidHours').value='';$('mTips').value='';$('mNote').value=''}$('monthModal').dataset.edit=k;$('monthModal').classList.add('show');updateLiveCalc();renderPaymentListInMonth()}
function modalMonthKey(){return monthKey(Number($('mYear').value),Number($('mMonth').value))}
function saveMonth(){const y=Number($('mYear').value),m=Number($('mMonth').value);if(!y||!m)return;const k=monthKey(y,m),existing=data.months[k]||{};data.months[k]={...existing,workedMinutes:parseDuration($('mWorked').value),officialMinutes:parseDuration($('mOfficialHours').value),paidMinutes:parseDuration($('mPaidHours').value),tips:Number($('mTips').value)||0,note:$('mNote').value.trim(),_daysAuto:false};closeModal('monthModal');persist()}
function updateLiveCalc(){const k=modalMonthKey(),rate=rateFor(k),w=parseDuration($('mWorked').value),o=parseDuration($('mOfficialHours').value),p=parseDuration($('mPaidHours').value),earned=w/60*rate,paid=p/60*rate;$('liveEarned').textContent=euro(earned);$('livePaid').textContent=euro(paid);$('liveOpen').textContent=euro(earned-paid);$('liveOpen').className=earned-paid>0?'money-open':'money-ok';if(!o)$('employerCompareLive').innerHTML='<b>Arbeitgeber-Abgleich:</b> Noch keine offizielle Zeit eingetragen.';else{const d=w-o;$('employerCompareLive').innerHTML=`<b>Arbeitgeber-Abgleich:</b> Eigene Zeit ${duration(w)} · Arbeitgeber ${duration(o)} · <span class="${d===0?'positive':'negative'}">Differenz ${signedDuration(d)}</span>`}renderPaymentListInMonth()}
function renderPaymentListInMonth(){const k=modalMonthKey(),ps=paymentsFor(k);$('paymentListInMonth').innerHTML=ps.length?`<div class="small" style="margin-bottom:4px"><b>Auszahlungen für diesen Monat</b></div>`+ps.map(p=>`<div class="payment"><div><b>${p.date?new Date(p.date+'T12:00:00').toLocaleDateString('de-DE'):'ohne Datum'}</b><br><span>${esc(p.note||'Auszahlung')}</span></div><div style="text-align:right"><b>${duration(p.hoursMinutes)}</b><br><span>${euro(p.amount)}</span></div></div>`).join(''):''}
function openPaymentForCurrentModal(){const k=modalMonthKey();$('pMonth').value=k;$('pDate').value=new Date().toISOString().slice(0,10);$('pHours').value=$('mPaidHours').value||'';const rate=rateFor(k),mins=parseDuration($('pHours').value);$('pAmount').value=mins?fmt(mins/60*rate).replace('.','').replace(',','.'):'';$('pNote').value='';$('paymentModal').classList.add('show')}
function savePayment(){const k=$('pMonth').value;if(!k)return;const p={id:Date.now(),month:k,date:$('pDate').value,hoursMinutes:parseDuration($('pHours').value),amount:Number($('pAmount').value)||0,note:$('pNote').value.trim()};data.payments.push(p);const existing=data.months[k]||{workedMinutes:0,officialMinutes:0,tips:0,note:''};existing.paidMinutes=paymentsFor(k).reduce((s,x)=>s+Number(x.hoursMinutes||0),0);data.months[k]=existing;$('mPaidHours').value=durationInput(existing.paidMinutes);closeModal('paymentModal');updateLiveCalc();persist();$('monthModal').classList.add('show')}

function syncMonthFromDays(k){if(!k)return;const sum=monthDays(k).reduce((a,d)=>a+dayMinutes(d),0),existing=data.months[k]||{paidMinutes:0,officialMinutes:0,tips:0,note:''};data.months[k]={...existing,workedMinutes:sum,_daysAuto:true}}
function calcDayMinutes(){if(!$('dStart').value||!$('dEnd').value)return 0;const [sh,sm]=$('dStart').value.split(':').map(Number),[eh,em]=$('dEnd').value.split(':').map(Number);let mins=(eh*60+em)-(sh*60+sm);if(mins<0)mins+=1440;mins-=Number($('dBreak').value||0);return Math.max(0,Math.round(mins))}
function updateDayPreview(){$('dayDurationPreview').innerHTML=`<b>Arbeitszeit:</b> ${duration(calcDayMinutes())}`}
function openDay(index=''){if(index!==''&&data.days[index]){const d=data.days[index];$('dDate').value=d.date||'';$('dStart').value=d.start||'';$('dEnd').value=d.end||'';$('dBreak').value=d.breakMin||0;$('dNote').value=d.note||'';$('dayModal').dataset.edit=String(index);$('deleteDayBtn').style.display='block'}else{$('dDate').value=new Date().toISOString().slice(0,10);$('dStart').value='15:00';$('dEnd').value='';$('dBreak').value=0;$('dNote').value='';$('dayModal').dataset.edit='';$('deleteDayBtn').style.display='none'}$('dayModal').classList.add('show');updateDayPreview()}
function saveDay(){if(!$('dDate').value)return;const item={date:$('dDate').value,start:$('dStart').value,end:$('dEnd').value,breakMin:Number($('dBreak').value)||0,minutes:calcDayMinutes(),note:$('dNote').value.trim()},edit=$('dayModal').dataset.edit;let oldKey='';if(edit!==''&&data.days[Number(edit)]){oldKey=dayMonthKey(data.days[Number(edit)].date);data.days[Number(edit)]=item}else data.days.push(item);const newKey=dayMonthKey(item.date);syncMonthFromDays(newKey);if(oldKey&&oldKey!==newKey)syncMonthFromDays(oldKey);closeModal('dayModal');persist()}
function deleteDay(){const edit=$('dayModal').dataset.edit;if(edit==='')return;const i=Number(edit);if(!data.days[i]||!confirm('Diesen Arbeitstag wirklich löschen?'))return;const oldKey=dayMonthKey(data.days[i].date);data.days.splice(i,1);syncMonthFromDays(oldKey);closeModal('dayModal');persist()}
function closeModal(id){$(id)?.classList.remove('show')}
function saveSettings(){const oldRate=Number(data.settings.hourlyRate)||0,oldLimit=Number(data.settings.limit)||603,newRate=Number($('hourlyRate').value)||0,newLimit=Number($('limit').value)||603,k=actualCurrentKey();data.settings.hourlyRate=newRate;data.settings.limit=newLimit;data.settings.currentYear=Number($('currentYear').value)||new Date().getFullYear();if(newRate!==oldRate)data.settings.rateHistory[k]=newRate;if(newLimit!==oldLimit)data.settings.limitHistory[k]=newLimit;persist()}

function saveTextFile(name,text,type){if(window.Android&&typeof Android.saveTextFile==='function'){Android.saveTextFile(name,type||'text/plain',text);return}const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type:type||'text/plain'}));a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),700)}
function backupFileName(prefix='Stundenkonto_Backup'){const d=new Date(),pad=n=>String(n).padStart(2,'0');return `${prefix}_${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}.json`}function exportBackup(){data.settings.lastBackupAt=Date.now();data.backupVersion=2;data.appVersion='6.1.0';data.createdAt=new Date().toISOString();localStorage.setItem(key,JSON.stringify(data));saveTextFile(backupFileName(),JSON.stringify(data,null,2),'application/json');renderBackupStatus()}
function importBackup(file){if(!file)return;const r=new FileReader();r.onload=()=>{try{const raw=JSON.parse(r.result);if(!raw||typeof raw!=='object'||(!raw.months&&!raw.days&&!raw.settings))throw new Error('format');const candidate=normalize(raw),months=Object.keys(candidate.months||{}).length,days=(candidate.days||[]).length,pays=(candidate.payments||[]).length,when=raw.createdAt?new Date(raw.createdAt).toLocaleString('de-DE'):'Datum unbekannt';if(!confirm(`Backup prüfen\n\nErstellt: ${when}\n${months} Monate · ${days} Arbeitstage · ${pays} Auszahlungen\n\nDieses Backup wirklich wiederherstellen?`))return;const safety={...data,backupVersion:2,appVersion:'6.1.0',createdAt:new Date().toISOString()};saveTextFile(backupFileName('Stundenkonto_Sicherheitsbackup_vor_Import'),JSON.stringify(safety,null,2),'application/json');data=candidate;data.settings.lastBackupAt=Date.now();persist();alert('Backup erfolgreich wiederhergestellt. Vor dem Import wurde automatisch ein Sicherheitsbackup gespeichert.')}catch(e){alert('Diese Datei ist kein gültiges Stundenkonto-Backup.')}};r.readAsText(file)}
function csvText(rows){return rows.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(';')).join('\n')}
function exportReportCSV(){if(reportMode==='month'){const y=Number($('monthReportYear').value||data.settings.currentYear),m=Number($('monthReportMonth').value||new Date().getMonth()+1),k=monthKey(y,m),x=calcMonth(k),days=monthDays(k).slice().sort((a,b)=>a.date.localeCompare(b.date));let rows=[['Monatsbericht',`${MONTHS[m-1]} ${y}`],[],['Eigene Arbeitszeit',durationInput(x.workedMinutes)],['Arbeitgeber-Zeit',x.officialMinutes?durationInput(x.officialMinutes):''],['Differenz Arbeitgeber',x.officialDiff===null?'':durationInput(Math.abs(x.officialDiff))],['Ausgezahlte Zeit',durationInput(x.paidMinutes)],['Erarbeiteter Verdienst',fmt(x.workedPay)],['Rechnerisch ausgezahlt',fmt(x.paidSalary)],['Offenes Gehalt',fmt(x.earnDiff)],['Trinkgeld',fmt(x.tips)],['Arbeitstage',days.length],['Stundenlohn',fmt(x.rate)],['Minijob-Grenze',fmt(x.limit)],[],['Datum','Beginn','Ende','Pause Min.','Arbeitszeit','Notiz']];days.forEach(d=>rows.push([d.date,d.start||'',d.end||'',d.breakMin||0,durationInput(dayMinutes(d)),d.note||'']));saveTextFile(`Stundenkonto_${y}_${String(m).padStart(2,'0')}.csv`,csvText(rows),'text/csv;charset=utf-8')}else{const y=Number($('reportYear').value||data.settings.currentYear);let rows=[['Monat','Eigene Arbeitszeit','Arbeitgeber-Zeit','Ausgezahlte Zeit','Saldo Zeit','Erarbeiteter Verdienst','Rechnerisch ausgezahlt','Offenes Gehalt','Trinkgeld']];yearMonths(y).forEach(([k,m])=>rows.push([MONTHS[Number(k.slice(5))-1],durationInput(m.workedMinutes),m.officialMinutes?durationInput(m.officialMinutes):'',durationInput(m.paidMinutes),durationInput(Math.abs(m.diffMinutes)),fmt(m.workedPay),fmt(m.paidSalary),fmt(m.earnDiff),fmt(m.tips)]));saveTextFile(`Stundenkonto_${y}.csv`,csvText(rows),'text/csv;charset=utf-8')}}
function buildPrintReport(){if(reportMode==='month'){const y=Number($('monthReportYear').value||data.settings.currentYear),m=Number($('monthReportMonth').value||new Date().getMonth()+1),k=monthKey(y,m),x=calcMonth(k),days=monthDays(k).slice().sort((a,b)=>a.date.localeCompare(b.date));return `<h1>Stundenkonto Grüttner</h1><h2>Monatsbericht ${MONTHS[m-1]} ${y}</h2><div class="print-summary"><div><b>Eigene Arbeitszeit</b><br>${duration(x.workedMinutes)}</div><div><b>Arbeitgeber-Zeit</b><br>${x.officialMinutes?duration(x.officialMinutes):'nicht eingetragen'}</div><div><b>Ausgezahlte Zeit</b><br>${duration(x.paidMinutes)}</div><div><b>Offenes Gehalt</b><br>${euro(x.earnDiff)}</div><div><b>Erarbeitet</b><br>${euro(x.workedPay)}</div><div><b>Trinkgeld</b><br>${euro(x.tips)}</div></div><h2>Arbeitstage</h2><table><tr><th>Datum</th><th>Beginn</th><th>Ende</th><th>Pause</th><th>Zeit</th><th>Notiz</th></tr>${days.map(d=>`<tr><td>${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</td><td>${d.start||''}</td><td>${d.end||''}</td><td>${d.breakMin||0} Min.</td><td>${duration(dayMinutes(d))}</td><td>${esc(d.note||'')}</td></tr>`).join('')}</table><p>Arbeitgeber-Abgleich: ${x.officialDiff===null?'nicht möglich':signedDuration(x.officialDiff)}</p><p>Erstellt am ${new Date().toLocaleDateString('de-DE')} · privates Stundenkonto</p>`}const y=Number($('reportYear').value||data.settings.currentYear),ms=yearMonths(y),t=totals(y);return `<h1>Stundenkonto Grüttner</h1><h2>Jahresbericht ${y}</h2><div class="print-summary"><div><b>Gearbeitet</b><br>${duration(t.workedMinutes)}</div><div><b>Erarbeitet</b><br>${euro(t.workedPay)}</div><div><b>Ausgezahlte Zeit</b><br>${duration(t.paidMinutes)}</div><div><b>Jahressaldo</b><br>${signedDuration(t.diffMinutes)}</div></div><h2>Monate</h2><table><tr><th>Monat</th><th>Gearbeitet</th><th>Arbeitgeber</th><th>Ausgezahlt</th><th>Offen €</th><th>Trinkgeld</th></tr>${ms.map(([k,m])=>`<tr><td>${MONTHS[Number(k.slice(5))-1]}</td><td>${duration(m.workedMinutes)}</td><td>${m.officialMinutes?duration(m.officialMinutes):'–'}</td><td>${duration(m.paidMinutes)}</td><td>${euro(m.earnDiff)}</td><td>${euro(m.tips)}</td></tr>`).join('')}</table><p>Erstellt am ${new Date().toLocaleDateString('de-DE')} · privates Stundenkonto</p>`}
function exportReportPDF(){$('printReport').innerHTML=buildPrintReport();const name=reportMode==='month'?`Stundenkonto Monatsbericht`:`Stundenkonto Jahresbericht`;if(window.Android&&typeof Android.printPage==='function'){setTimeout(()=>Android.printPage(name),120)}else{window.print()}}
function resetAll(){if(!confirm('Wirklich alle Daten auf diesem Gerät löschen?'))return;if(!confirm('Letzte Sicherheitsabfrage: Alle Monate, Arbeitstage und Auszahlungen werden gelöscht. Fortfahren?'))return;data=seed();persist()}

window.addEventListener('load',()=>{try{if('serviceWorker'in navigator)navigator.serviceWorker.getRegistrations().then(rs=>rs.forEach(r=>r.unregister())).catch(()=>{});if('caches'in window)caches.keys().then(ks=>ks.forEach(k=>caches.delete(k))).catch(()=>{})}catch(e){};['mWorked','mOfficialHours','mPaidHours'].forEach(id=>$(id).addEventListener('input',updateLiveCalc));['mYear','mMonth'].forEach(id=>$(id).addEventListener('change',updateLiveCalc));['dStart','dEnd','dBreak'].forEach(id=>$(id).addEventListener('input',updateDayPreview));persist()});


let detectedOfficialMinutes=0;
function renderAssistant(){
  if(!$('assistantMonthCheck'))return;
  const k=actualCurrentKey(),x=calcMonth(k),days=monthDays(k),issues=[];
  if(!days.length)issues.push('Noch keine Arbeitstage im aktuellen Monat erfasst.');
  if(x.workedPay>x.limit)issues.push(`Minijob-Grenze um ${euro(x.workedPay-x.limit)} überschritten.`);
  if(x.officialMinutes&&x.officialDiff!==0)issues.push(`Arbeitgeber-Abweichung: ${signedDuration(x.officialDiff)}.`);
  if(!x.officialMinutes)issues.push('Arbeitgeber-Zeit für den laufenden Monat noch nicht hinterlegt.');
  $('assistantMonthCheck').innerHTML=issues.length?`<b>${issues.length} Hinweis${issues.length>1?'e':''}</b><div class="small" style="margin-top:7px">${issues.map(x=>'• '+esc(x)).join('<br>')}</div>`:'<b>✓ Keine Auffälligkeiten erkannt</b><div class="small" style="margin-top:7px">Der aktuelle Monat wirkt plausibel.</div>';
  if($('scanMonth')&&!$('scanMonth').options.length){const years=reportYears().slice().reverse(),cur=actualCurrentKey();$('scanMonth').innerHTML=years.flatMap(y=>MONTHS.map((m,i)=>{const k=monthKey(Number(y),i+1);return `<option value="${k}" ${k===cur?'selected':''}>${m} ${y}</option>`})).join('')}
}
function assistantAnswer(msg,error=false){if(!$('assistantAnswer'))return;$('assistantAnswer').textContent=msg;$('assistantAnswer').className='assistant-answer'+(error?' error':'')}
function startVoiceAssistant(){if(window.Android&&typeof Android.startVoiceInput==='function'){Android.startVoiceInput()}else assistantAnswer('Spracheingabe ist in dieser Umgebung nicht verfügbar.',true)}
window.receiveVoiceText=function(t){$('assistantInput').value=t||'';runAssistant()}
function parseWorkCommand(q){const s=q.toLowerCase();const times=[...q.matchAll(/\b([01]?\d|2[0-3])[:.]([0-5]\d)\b/g)].map(m=>`${String(m[1]).padStart(2,'0')}:${m[2]}`);if(times.length<2)return null;let date=new Date().toISOString().slice(0,10);if(/gestern/.test(s)){const d=new Date();d.setDate(d.getDate()-1);date=d.toISOString().slice(0,10)}const pauseM=s.match(/(?:pause\s*)?(\d{1,3})\s*(?:min|minute)/);const pause=/keine\s+pause/.test(s)?0:(pauseM?Number(pauseM[1]):0);let note='';const known=['küche','service','veranstaltung','frühstück','abendessen'];const n=known.find(x=>s.includes(x));if(n)note=n.charAt(0).toUpperCase()+n.slice(1);return {date,start:times[0],end:times[1],pause,note}}
function prefillWorkDay(x){openDay();$('dDate').value=x.date;$('dStart').value=x.start;$('dEnd').value=x.end;$('dBreak').value=x.pause;$('dNote').value=x.note;updateDayPreview()}
function runAssistant(){const q=($('assistantInput').value||'').trim();if(!q)return assistantAnswer('Schreib mir eine Frage oder einen Arbeitstag.');const s=q.toLowerCase(),k=actualCurrentKey(),x=calcMonth(k),t=totals(Number(data.settings.currentYear)),bal=closedBalance(),open=closedOpenMoney(),avg=avgDay(k),limit=x.limit||603,rem=Math.max(0,limit-x.workedPay),remM=x.rate?Math.floor(rem/x.rate*60):0;
  const cmd=parseWorkCommand(q);if(cmd){prefillWorkDay(cmd);assistantAnswer(`Arbeitstag erkannt: ${cmd.start}–${cmd.end}${cmd.pause?`, ${cmd.pause} Min. Pause`:', keine Pause'}. Ich habe das Formular vorbereitet. Bitte prüfen und speichern.`);return}
  if(/offen|schuldet|guthaben/.test(s)&&/stund/.test(s)){assistantAnswer(`Aus abgeschlossenen Monaten sind aktuell ${signedDuration(bal)} offen. Das entspricht rechnerisch ${open>=0?'+':''}${euro(open)}.`);return}
  if(/offen|schuldet/.test(s)&&/(geld|gehalt|euro|€)/.test(s)){assistantAnswer(`Rechnerisch noch offenes Gehalt aus abgeschlossenen Monaten: ${open>=0?'+':''}${euro(open)}.`);return}
  if(/grenze|noch.*arbeiten|rest/.test(s)){assistantAnswer(`Im aktuellen Monat sind ${euro(x.workedPay)} von ${euro(limit)} erarbeitet. Es bleiben ${euro(rem)} bzw. ungefähr ${duration(remM)} mögliche Arbeitszeit.${avg?` Bei deinem aktuellen Schnitt von ${duration(avg)} pro Einsatz sind das etwa ${Math.floor(remM/avg)} volle Einsätze.`:''}`);return}
  if(/trinkgeld/.test(s)){assistantAnswer(`Im Jahr ${data.settings.currentYear} hast du ${euro(t.tips)} Trinkgeld erfasst.`);return}
  if(/meisten|höchsten/.test(s)&&/stund/.test(s)){const arr=yearMonths(Number(data.settings.currentYear));if(!arr.length)return assistantAnswer('Es sind noch keine Monate vorhanden.');const [mk,m]=arr.reduce((a,b)=>b[1].workedMinutes>a[1].workedMinutes?b:a);assistantAnswer(`Die meisten Stunden im Jahr ${data.settings.currentYear} hattest du im ${MONTHS[Number(mk.slice(5))-1]}: ${duration(m.workedMinutes)}.`);return}
  if(/jahr|dieses jahr|gesamt/.test(s)&&/(verdient|erarbeitet|gehalt)/.test(s)){assistantAnswer(`Im Jahr ${data.settings.currentYear} hast du bisher ${euro(t.workedPay)} erarbeitet bei ${duration(t.workedMinutes)} Arbeitszeit.`);return}
  if(/prüf|check|auffällig/.test(s)){renderAssistant();assistantAnswer('Ich habe den aktuellen Monat geprüft. Die Hinweise findest du direkt im Monatscheck darunter.');return}
  assistantAnswer('Das kann ich aktuell sicher beantworten: offene Stunden/Gehalt, Monatsgrenze und Restarbeitszeit, Jahresverdienst, Trinkgeld, stärkster Monat sowie Monatscheck. Du kannst außerdem einen Arbeitstag in einem Satz diktieren.');
}
function scanEmployerImage(file){if(!file)return;if(!file.type.startsWith('image/'))return assistantAnswer('Bitte ein Foto oder einen Screenshot auswählen.',true);$('scanBox').classList.remove('hidden');$('scanResult').textContent='Bild wird analysiert …';$('applyOfficialBtn').classList.add('hidden');const r=new FileReader();r.onload=()=>{if(window.Android&&typeof Android.recognizeImage==='function')Android.recognizeImage(r.result);else $('scanResult').textContent='Texterkennung ist nur in der Android-App verfügbar.'};r.readAsDataURL(file)}
window.onOcrResult=function(text,error){if(error){$('scanResult').textContent=error;return}const clean=(text||'').trim();$('scanResult').textContent=clean||'Kein Text erkannt.';detectedOfficialMinutes=extractOfficialMinutes(clean);if(detectedOfficialMinutes>0){$('applyOfficialBtn').classList.remove('hidden');$('applyOfficialBtn').textContent=`${duration(detectedOfficialMinutes)} als Arbeitgeberzeit übernehmen`;const k=$('scanMonth').value,x=calcMonth(k),d=x.workedMinutes-detectedOfficialMinutes;assistantAnswer(`Auf dem Bild habe ich als wahrscheinlichste Gesamtarbeitszeit ${duration(detectedOfficialMinutes)} erkannt. Für ${MONTHS[Number(k.slice(5))-1]} ${k.slice(0,4)} ergibt das gegenüber deiner Erfassung ${signedDuration(d)} Differenz.`)}else assistantAnswer('Der Text wurde erkannt, aber ich konnte keine eindeutige Gesamtarbeitszeit ableiten. Prüfe den erkannten Text.',true)}
function extractOfficialMinutes(t){const lines=String(t||'').split(/\n+/);for(const l of lines){if(/arbeitszeit\s*gesamt|gesamtarbeitszeit|gesamt\s*stunden|stunden\s*gesamt/i.test(l)){const m=l.match(/(\d{1,3})[:.]([0-5]\d)/);if(m)return Number(m[1])*60+Number(m[2])}}const matches=[...String(t||'').matchAll(/\b(\d{1,3})[:.]([0-5]\d)\b/g)].map(m=>Number(m[1])*60+Number(m[2])).filter(v=>v>=60);return matches.length?Math.max(...matches):0}
function applyDetectedOfficialHours(){if(!detectedOfficialMinutes)return;const k=$('scanMonth').value,ex=data.months[k]||{workedMinutes:0,paidMinutes:0,tips:0,note:''};data.months[k]={...ex,officialMinutes:detectedOfficialMinutes};persist();assistantAnswer(`${duration(detectedOfficialMinutes)} wurden als Arbeitgeberzeit für ${MONTHS[Number(k.slice(5))-1]} ${k.slice(0,4)} gespeichert.`);$('applyOfficialBtn').classList.add('hidden')}


/* ===== v5.0 Komfort, Kalender, Erinnerungen, Archiv, Statistik, Historie ===== */
function seed(){return {backupVersion:3,appVersion:'6.1.0',createdAt:new Date().toISOString(),settings:{hourlyRate:0,limit:603,currentYear:new Date().getFullYear(),rateHistory:{},limitHistory:{},lastBackupAt:0,routineDays:[2,4],routineStart:'15:00',routineEnd:'20:00',remindersEnabled:false,darkMode:false,appLock:false},months:{},days:[],payments:[],audit:[]}}
function normalize(raw){
  const d=(raw&&typeof raw==='object')?raw:seed(),def=seed();
  d.settings={...def.settings,...(d.settings||{})};
  d.settings.rateHistory=(d.settings.rateHistory&&typeof d.settings.rateHistory==='object')?d.settings.rateHistory:{};
  d.settings.limitHistory=(d.settings.limitHistory&&typeof d.settings.limitHistory==='object')?d.settings.limitHistory:{};
  d.settings.routineDays=Array.isArray(d.settings.routineDays)?d.settings.routineDays.map(Number):[2,4];
  if(!Object.keys(d.settings.rateHistory).length&&Number(d.settings.hourlyRate))d.settings.rateHistory['0000-01']=Number(d.settings.hourlyRate);
  if(!Object.keys(d.settings.limitHistory).length&&Number(d.settings.limit))d.settings.limitHistory['0000-01']=Number(d.settings.limit);
  d.months=d.months&&typeof d.months==='object'?d.months:{};d.days=Array.isArray(d.days)?d.days:[];d.payments=Array.isArray(d.payments)?d.payments:[];d.audit=Array.isArray(d.audit)?d.audit:[];
  d.days=d.days.map(x=>({...x,minutes:dayMinutes(x)}));
  d.payments=d.payments.map(p=>({...p,hoursMinutes:Number.isFinite(Number(p.hoursMinutes))?Math.round(Number(p.hoursMinutes)):parseDuration(p.hours||''),amount:Number(p.amount)||0}));
  for(const [k,x0] of Object.entries(d.months)){
    const x=x0||{},daySum=d.days.filter(q=>dayMonthKey(q.date)===k).reduce((a,q)=>a+dayMinutes(q),0);
    let workedMinutes=Number.isFinite(Number(x.workedMinutes))?Math.round(Number(x.workedMinutes)):0;if(!workedMinutes)workedMinutes=(x._daysAuto&&daySum)?daySum:legacyClockToMinutes(x.worked);
    let paidMinutes=Number.isFinite(Number(x.paidMinutes))?Math.round(Number(x.paidMinutes)):legacyClockToMinutes(x.paidHours);
    let officialMinutes=Number.isFinite(Number(x.officialMinutes))?Math.round(Number(x.officialMinutes)):legacyClockToMinutes(x.officialHours);
    const booked=d.payments.filter(p=>p.month===k).reduce((a,p)=>a+Number(p.hoursMinutes||0),0);if(booked>0)paidMinutes=booked;
    d.months[k]={...x,workedMinutes,paidMinutes,officialMinutes,documents:Array.isArray(x.documents)?x.documents:[]};
  }
  d.backupVersion=Number(d.backupVersion)||1;d.appVersion='5.0.0';return d;
}
function audit(action,detail=''){data.audit=data.audit||[];data.audit.unshift({ts:Date.now(),action,detail});if(data.audit.length>250)data.audit=data.audit.slice(0,250)}
function persist(){data.backupVersion=3;data.appVersion='6.1.0';localStorage.setItem(key,JSON.stringify(data));render()}

let calendarDate=new Date();calendarDate.setDate(1);
function changeCalendarMonth(delta){calendarDate.setMonth(calendarDate.getMonth()+delta);renderCalendar()}
function openCalendarDate(ds,idx){
  if(idx>=0&&data.days[idx]){openDay(idx);return}
  openDay();
  $('dDate').value=ds;
  const dt=new Date(ds+'T12:00:00'),dow=dt.getDay(),routine=(data.settings.routineDays||[2,4]).includes(dow);
  $('dStart').value='15:00';
  $('dEnd').value=routine?'20:00':'';
  $('dBreak').value=0;
  updateDayPreview();
}
function renderCalendar(){if(!$('calendarGrid'))return;const y=calendarDate.getFullYear(),m=calendarDate.getMonth(),daysIn=new Date(y,m+1,0).getDate(),first=(new Date(y,m,1).getDay()+6)%7,labels=['Mo','Di','Mi','Do','Fr','Sa','So'];$('calendarTitle').textContent=`${MONTHS[m]} ${y}`;let html=labels.map(x=>`<div class="cal-label">${x}</div>`).join('');for(let i=0;i<first;i++)html+='<div class="cal-day empty"></div>';const today=new Date().toISOString().slice(0,10);for(let d=1;d<=daysIn;d++){const ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,idx=data.days.findIndex(x=>x.date===ds),entry=idx>=0?data.days[idx]:null,dow=new Date(y,m,d).getDay(),routine=(data.settings.routineDays||[2,4]).includes(dow);html+=`<div class="cal-day ${entry?'work':''} ${routine?'routine':''} ${ds===today?'today':''}" onclick="openCalendarDate('${ds}',${idx})"><b>${d}</b>${entry?`<span class="cal-hours">${duration(dayMinutes(entry))}</span>`:''}</div>`}$('calendarGrid').innerHTML=html}
function renderDays(){renderCalendar();const arr=data.days.map((d,i)=>({...d,_index:i})).sort((a,b)=>(b.date||'').localeCompare(a.date||''));if(!arr.length){$('dayList').innerHTML='<div class="card small">Noch keine Arbeitstage erfasst.</div>';return}$('dayList').innerHTML=arr.map(d=>`<div class="month" onclick="openDay(${d._index})"><div class="monthhead"><div><div class="monthtitle">${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</div><div class="small">${d.start||'–'} bis ${d.end||'–'} · Pause ${d.breakMin||0} Min.</div></div><b>${duration(dayMinutes(d))}</b></div><div class="small" style="margin-top:6px">${esc(d.note||'Antippen zum Bearbeiten')}</div></div>`).join('')}

function routineShiftMinutes(){const [sh,sm]=(data.settings.routineStart||'15:00').split(':').map(Number),[eh,em]=(data.settings.routineEnd||'20:00').split(':').map(Number);let v=(eh*60+em)-(sh*60+sm);if(v<0)v+=1440;return v||300}
function nextRoutineDates(count=4){const out=[],d=new Date();d.setHours(12,0,0,0);for(let i=0;i<45&&out.length<count;i++){d.setDate(d.getDate()+(i?1:0));if((data.settings.routineDays||[2,4]).includes(d.getDay()))out.push(new Date(d))}return out}
function renderCurrentMonth(){const k=actualCurrentKey(),[y,m]=k.split('-').map(Number),x=calcMonth(k),limit=x.limit||603,pctRaw=limit>0?x.workedPay/limit*100:0,pct=Math.max(0,Math.min(100,pctRaw)),remaining=Math.max(0,limit-x.workedPay),remainingMinutes=x.rate>0?Math.floor(remaining/x.rate*60):0,avg=avgDay(k),routine=routineShiftMinutes(),base=avg>=180?avg:routine,full=base>0?Math.floor(remainingMinutes/base):0,remainder=base>0?remainingMinutes-full*base:remainingMinutes;let cls='ok',msg='Alles im grünen Bereich.';if(pctRaw>=100){cls='over';msg=`Grenze erreicht/überschritten um ${euro(Math.max(0,x.workedPay-limit))}.` }else if(pctRaw>=90){cls='warn90';msg='Über 90 % der Monatsgrenze – weitere Einsätze genau planen.'}else if(pctRaw>=80){cls='warn80';msg='Über 80 % der Monatsgrenze – Restarbeitszeit im Blick behalten.'}const dates=nextRoutineDates(Math.min(4,full+1)).map(d=>d.toLocaleDateString('de-DE',{weekday:'short',day:'2-digit',month:'2-digit'})).join(' · ');$('currentMonthCard').innerHTML=`<div class="current-head"><div><div class="small">AKTUELLER MONAT</div><div class="current-title">${MONTHS[m-1]} ${y}</div><div class="small" style="margin-top:3px">${duration(x.workedMinutes)} gearbeitet · ${monthDays(k).length} Einsätze</div></div><div style="text-align:right"><b>${euro(x.workedPay)}</b><div class="small">erarbeitet</div></div></div><div class="limitbar"><i style="width:${pct}%"></i></div><div class="minirow"><span>${euro(x.workedPay)} von ${euro(limit)}</span><span>${fmt(pctRaw,0)} %</span></div><div class="limit-warning ${cls}">${msg}</div><div class="current-extra"><div><b>${euro(remaining)}</b><span>noch bis zur Grenze</span></div><div><b>${duration(remainingMinutes)}</b><span>noch mögliche Arbeitszeit</span></div><div><b>${avg?duration(avg):duration(routine)}</b><span>${avg?'Ø je Arbeitstag':'deine Routine'}</span></div><div><b>${full} + ${duration(remainder)}</b><span>volle Einsätze + Rest</span></div></div><div class="forecast-box"><b>Planung mit deiner Routine Di/Do ${data.settings.routineStart||'15:00'}–${data.settings.routineEnd||'20:00'}</b><br>${full?`${full} volle Einsätze à etwa ${duration(base)}${remainder?` plus ${duration(remainder)} Restzeit`:''}.`:`Kein voller Routine-Einsatz mehr innerhalb der Grenze.`}${dates?`<br>Nächste reguläre Tage: ${dates}`:''}<br><span class="small">Ausnahmen kannst du weiterhin jederzeit normal erfassen.</span></div>`;const b=closedBalance(),money=closedOpenMoney();$('closedAccountStrip').innerHTML=`<div><b>Stundenkonto aus Vormonaten</b><br><span>${b>0?'Guthaben beim Arbeitgeber':b<0?'Überzahlung / Minussaldo':'aktuell ausgeglichen'}</span></div><div style="text-align:right"><b class="${b>=0?'positive':'negative'}">${signedDuration(b)}</b><br><span>${money>=0?'+':''}${euro(money)}</span></div>`}

function monthFinalized(k){return !!data.months?.[k]?.finalizedAt}
function finalizeMonth(k){const x=calcMonth(k),c=monthChecklist(k,x);if(c.done<3&&!confirm(`Der Monatscheck ist erst ${c.done}/3 vollständig. Trotzdem abschließen?`))return;if(k===actualCurrentKey()&&!confirm('Dieser Monat läuft noch. Wirklich bereits als geprüft/abgeschlossen markieren?'))return;data.months[k]={...(data.months[k]||{}),finalizedAt:Date.now()};audit('Monat abgeschlossen',k);persist()}
function reopenMonth(k){if(!confirm('Monatsabschluss wieder öffnen?'))return;data.months[k]={...(data.months[k]||{}),finalizedAt:0};audit('Monat wieder geöffnet',k);persist()}
function monthCheckHtml(k,x){const c=monthChecklist(k,x),final=monthFinalized(k);return `<div class="status-card"><div style="display:flex;justify-content:space-between;gap:8px;align-items:center"><b>Monatsabschluss-Check · ${c.done}/3 erledigt</b>${final?'<span class="close-badge">✓ abgeschlossen</span>':''}</div><div class="status-grid"><div class="status-item"><b>${c.ds?'✓':'○'} Arbeitstage</b><span>${c.ds?'erfasst':'noch prüfen'}</span></div><div class="status-item"><b>${c.official?'✓':'○'} Arbeitgeberzeit</b><span>${c.official?'eingetragen':'fehlt'}</span></div><div class="status-item"><b>${c.paid?'✓':'○'} Auszahlung</b><span>${c.paid?'erfasst':'noch offen'}</span></div><div class="status-item"><b>${x.diffMinutes>0?'+':''}${duration(x.diffMinutes)}</b><span>Monatssaldo</span></div></div><div style="height:9px"></div><button class="btn ${final?'secondary':''} full" onclick="${final?`reopenMonth('${k}')`:`finalizeMonth('${k}')`}">${final?'Abschluss wieder öffnen':'Monat abschließen'}</button></div>`}

function monthDocs(k){return Array.isArray(data.months?.[k]?.documents)?data.months[k].documents:[]}
function pickPayrollDocument(k){if(window.Android&&Android.pickPayrollDocument)Android.pickPayrollDocument(k);else alert('Dokumentauswahl ist nur in der Android-App verfügbar.')}
window.onPayrollDocumentPicked=function(k,uri,name,mime){const ex=data.months[k]||{workedMinutes:0,paidMinutes:0,officialMinutes:0,tips:0};ex.documents=Array.isArray(ex.documents)?ex.documents:[];ex.documents.push({id:Date.now(),uri,name:name||'Dokument',mime:mime||''});data.months[k]=ex;audit('Abrechnung hinzugefügt',`${k}: ${name||'Dokument'}`);persist()}
function openPayrollDocument(uri){if(window.Android&&Android.openDocument)Android.openDocument(uri)}
function removePayrollDocument(k,id){if(!confirm('Dokument-Verknüpfung entfernen? Die Originaldatei wird nicht gelöscht.'))return;const ex=data.months[k];if(!ex)return;ex.documents=(ex.documents||[]).filter(d=>Number(d.id)!==Number(id));audit('Abrechnung entfernt',k);persist()}
function payrollArchiveHtml(k){const docs=monthDocs(k);return `<div class="report-note"><b>Lohnabrechnungs-Archiv</b><div style="height:7px"></div><button class="btn gold smallbtn" onclick="pickPayrollDocument('${k}')">PDF / Foto zuordnen</button>${docs.length?docs.map(d=>`<div class="doc-item"><div><b>${esc(d.name)}</b><br><span class="small">${esc(d.mime||'Datei')}</span></div><div><button class="btn secondary smallbtn" onclick="openPayrollDocument('${esc(d.uri)}')">Öffnen</button> <button class="btn danger smallbtn" onclick="removePayrollDocument('${k}',${d.id})">×</button></div></div>`).join(''):'<div class="small" style="margin-top:8px">Noch keine Abrechnung zugeordnet.</div>'}</div>`}

function renderStats(){if(!$('statsBox'))return;const y=Number(data.settings.currentYear),ms=yearMonths(y),allDays=data.days.filter(d=>(d.date||'').startsWith(y+'-')),mins=allDays.reduce((s,d)=>s+dayMinutes(d),0),earn=ms.reduce((s,[,m])=>s+m.workedPay,0),tips=ms.reduce((s,[,m])=>s+m.tips,0),avgM=allDays.length?Math.round(mins/allDays.length):0,max=Math.max(1,...ms.map(([,m])=>m.workedMinutes));$('statsBox').innerHTML=`<div class="summaryline"><div><b>${allDays.length}</b><span>Einsätze ${y}</span></div><div><b>${avgM?duration(avgM):'–'}</b><span>Ø pro Einsatz</span></div><div><b>${allDays.length?euro(earn/allDays.length):'–'}</b><span>Ø Verdienst/Einsatz</span></div><div><b>${euro(tips)}</b><span>Trinkgeld</span></div></div><div class="stats-bars">${ms.slice().reverse().map(([k,m])=>`<div class="statbar-row"><span>${MONTHS[Number(k.slice(5))-1].slice(0,3)}</span><div class="statbar-track"><div class="statbar-fill" style="width:${Math.max(2,m.workedMinutes/max*100)}%"></div></div><b>${duration(m.workedMinutes)}</b></div>`).join('')}</div>`}
function renderPayoutHistory(){if(!$('payoutHistory'))return;const ps=data.payments.slice().sort((a,b)=>(b.date||'').localeCompare(a.date||''));$('payoutHistory').innerHTML=ps.length?ps.map(p=>`<div class="payment"><div><b>${p.date?new Date(p.date+'T12:00:00').toLocaleDateString('de-DE'):'ohne Datum'}</b><br><span>${esc(p.note||p.month||'Auszahlung')} · ${p.month||''}</span></div><div style="text-align:right"><b>${duration(p.hoursMinutes)}</b><br><span>${euro(p.amount)}</span></div></div>`).join(''):'<div class="small">Noch keine Auszahlungen gebucht.</div>'}

function renderReports(){
  const years=reportYears(),current=String(data.settings.currentYear),yVal=$('reportYear').value||current,myVal=$('monthReportYear').value||current,mmVal=$('monthReportMonth').value||String(new Date().getMonth()+1);
  $('reportYear').innerHTML=years.map(y=>`<option value="${y}" ${y===yVal?'selected':''}>${y}</option>`).join('');$('monthReportYear').innerHTML=years.map(y=>`<option value="${y}" ${y===myVal?'selected':''}>${y}</option>`).join('');$('monthReportMonth').innerHTML=MONTHS.map((m,i)=>`<option value="${i+1}" ${String(i+1)===String(mmVal)?'selected':''}>${m}</option>`).join('');
  const t=totals(Number($('reportYear').value||yVal));$('reportBox').innerHTML=`<div class="summaryline"><div><b>${duration(t.workedMinutes)}</b><span>gearbeitet</span></div><div><b>${duration(t.paidMinutes)}</b><span>ausgezahlte Zeit</span></div><div><b class="${t.diffMinutes>0?'money-open':'money-ok'}">${signedDuration(t.diffMinutes)}</b><span>Jahressaldo</span></div><div><b>${euro(t.workedPay)}</b><span>erarbeitet</span></div><div><b>${euro(t.paidSalary)}</b><span>Gehalt rechnerisch</span></div><div><b class="${t.earnDiff>0?'money-open':'money-ok'}">${euro(t.earnDiff)}</b><span>rechnerisch offen</span></div><div><b>${euro(t.tips)}</b><span>Trinkgeld</span></div><div><b>${euro(t.totalPaid)}</b><span>inkl. Trinkgeld</span></div></div>`;
  const y=Number($('monthReportYear').value||myVal),m=Number($('monthReportMonth').value||mmVal),k=monthKey(y,m),x=calcMonth(k),days=monthDays(k).slice().sort((a,b)=>a.date.localeCompare(b.date)),avg=avgDay(k),pays=paymentsFor(k);
  $('monthReportBox').innerHTML=`<div class="summaryline"><div><b>${duration(x.workedMinutes)}</b><span>eigene Arbeitszeit</span></div><div><b>${x.officialMinutes?duration(x.officialMinutes):'–'}</b><span>Arbeitgeber-Zeit</span></div><div><b>${duration(x.paidMinutes)}</b><span>ausgezahlte Zeit</span></div><div><b>${euro(x.workedPay)}</b><span>erarbeitet</span></div><div><b>${euro(x.paidSalary)}</b><span>rechnerisch ausgezahlt</span></div><div><b class="${x.earnDiff>0?'money-open':'money-ok'}">${euro(x.earnDiff)}</b><span>offenes Gehalt</span></div><div><b>${euro(x.tips)}</b><span>Trinkgeld</span></div><div><b>${days.length}</b><span>Arbeitstage</span></div><div><b>${avg?duration(avg):'–'}</b><span>Ø pro Arbeitstag</span></div><div><b>${euro(x.rate)}</b><span>Stundenlohn</span></div></div>${employerCompareHtml(k,x)}${monthCheckHtml(k,x)}${pays.length?`<div class="report-note"><b>Gebuchte Auszahlungen:</b><br>${pays.map(p=>`${new Date(p.date+'T12:00:00').toLocaleDateString('de-DE')}: ${duration(p.hoursMinutes)} · ${euro(p.amount)}${p.note?' · '+esc(p.note):''}`).join('<br>')}</div>`:''}${payrollArchiveHtml(k)}${x.note?`<div class="report-note"><b>Monatsnotiz:</b> ${esc(x.note)}</div>`:''}`;
  $('monthReportDays').innerHTML=days.length?`<h3 style="margin:0 0 4px">Arbeitstage im Monat</h3>`+days.map(d=>`<div class="report-day"><div><b>${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</b><br><span>${d.start||'–'} bis ${d.end||'–'} · Pause ${d.breakMin||0} Min.${d.note?' · '+esc(d.note):''}</span></div><b>${duration(dayMinutes(d))}</b></div>`).join(''):`<div class="report-note">Für ${MONTHS[m-1]} ${y} sind keine einzelnen Arbeitstage erfasst.</div>`;
  $('reportExportBtn').textContent=reportMode==='month'?'Monatsbericht als CSV':'Jahresbericht als CSV';$('reportPdfBtn').textContent=reportMode==='month'?'Monatsbericht als PDF':'Jahresbericht als PDF';renderStats();renderPayoutHistory();
}

function renderAudit(){if(!$('auditLog'))return;const a=(data.audit||[]).slice(0,60);$('auditLog').innerHTML=a.length?a.map(x=>`<div class="audit-item"><b>${new Date(x.ts).toLocaleString('de-DE')}</b><br>${esc(x.action)}${x.detail?` · ${esc(x.detail)}`:''}</div>`).join(''):'<div class="small">Noch keine Änderungen protokolliert.</div>'}
function renderSettings(){document.body.classList.toggle('dark',!!data.settings.darkMode);$('hourlyRate').value=data.settings.hourlyRate;$('limit').value=data.settings.limit;$('currentYear').value=data.settings.currentYear;const rh=Object.entries(data.settings.rateHistory||{}).filter(([k])=>k!=='0000-01').sort().reverse(),lh=Object.entries(data.settings.limitHistory||{}).filter(([k])=>k!=='0000-01').sort().reverse();$('historyInfo').innerHTML=`<b>Historie</b><br>Stundenlohn: ${rh.length?rh.slice(0,3).map(([k,v])=>`${k}: ${euro(v)}`).join(' · '):'Basiswert gilt für bestehende Monate'}<br>Grenze: ${lh.length?lh.slice(0,3).map(([k,v])=>`${k}: ${euro(v)}`).join(' · '):'Basiswert gilt für bestehende Monate'}`;if($('dataStatus'))$('dataStatus').innerHTML=`<b>Gespeicherte Daten</b><br>${Object.keys(data.months).length} Monate · ${data.days.length} Arbeitstage · ${data.payments.length} Auszahlungen · ${(data.audit||[]).length} Historieneinträge`;if($('routineStart')){$('routineStart').value=data.settings.routineStart||'15:00';$('routineEnd').value=data.settings.routineEnd||'20:00';$('remindersEnabled').checked=!!data.settings.remindersEnabled;$('darkModeToggle').checked=!!data.settings.darkMode;$('appLockToggle').checked=!!data.settings.appLock;[2,4].forEach(d=>$(`day${d}chip`)?.classList.toggle('active',(data.settings.routineDays||[]).includes(d)))}renderAudit()}
function toggleRoutineDay(d){const arr=new Set(data.settings.routineDays||[2,4]);arr.has(d)?arr.delete(d):arr.add(d);data.settings.routineDays=[...arr].sort();renderSettings()}
function saveRoutineSettings(){data.settings.routineStart=$('routineStart').value||'15:00';data.settings.routineEnd=$('routineEnd').value||'20:00';data.settings.remindersEnabled=$('remindersEnabled').checked;audit('Arbeitsroutine geändert',`${data.settings.routineDays.join(',')} ${data.settings.routineStart}-${data.settings.routineEnd}`);if(window.Android&&Android.configureReminders)Android.configureReminders(JSON.stringify({enabled:data.settings.remindersEnabled,days:data.settings.routineDays,start:data.settings.routineStart,end:data.settings.routineEnd}));persist();alert('Routine gespeichert.')}
function toggleDarkMode(v){data.settings.darkMode=!!v;audit('Darstellung geändert',v?'Dark Mode an':'Dark Mode aus');persist()}
function toggleAppLock(v){data.settings.appLock=!!v;audit('App-Sperre geändert',v?'aktiviert':'deaktiviert');if(window.Android&&Android.setAppLockEnabled)Android.setAppLockEnabled(!!v);persist()}
function exportBackupCloud(){data.settings.lastBackupAt=Date.now();data.backupVersion=3;data.appVersion='6.1.0';data.createdAt=new Date().toISOString();localStorage.setItem(key,JSON.stringify(data));if(window.Android&&Android.saveBackupToCloud)Android.saveBackupToCloud(backupFileName(),JSON.stringify(data,null,2));else alert('Cloud-Speichern ist nur in der Android-App verfügbar.');renderBackupStatus()}

const _saveDayV4=saveDay;saveDay=function(){const edit=$('dayModal').dataset.edit,before=edit!==''&&data.days[Number(edit)]?JSON.stringify(data.days[Number(edit)]):null;_saveDayV4();audit(before?'Arbeitstag geändert':'Arbeitstag hinzugefügt',$('dDate')?.value||'');localStorage.setItem(key,JSON.stringify(data));render()}
const _deleteDayV4=deleteDay;deleteDay=function(){const edit=$('dayModal').dataset.edit,detail=edit!==''&&data.days[Number(edit)]?data.days[Number(edit)].date:'';_deleteDayV4();if(detail){audit('Arbeitstag gelöscht',detail);localStorage.setItem(key,JSON.stringify(data));render()}}
const _saveMonthV4=saveMonth;saveMonth=function(){const k=modalMonthKey();_saveMonthV4();audit('Monat geändert',k);localStorage.setItem(key,JSON.stringify(data));render()}
const _savePaymentV4=savePayment;savePayment=function(){const k=$('pMonth').value;_savePaymentV4();audit('Auszahlung gebucht',k);localStorage.setItem(key,JSON.stringify(data));render()}
const _saveSettingsV4=saveSettings;saveSettings=function(){_saveSettingsV4();audit('Grundeinstellungen geändert',`Stundenlohn ${data.settings.hourlyRate}, Grenze ${data.settings.limit}`);localStorage.setItem(key,JSON.stringify(data));render()}
const _exportBackupV4=exportBackup;exportBackup=function(){_exportBackupV4();if(window.Android&&Android.updateBackupTimestamp)Android.updateBackupTimestamp(data.settings.lastBackupAt)}

function render(){const y=Number(data.settings.currentYear),t=totals(y),b=closedBalance(),openMoney=closedOpenMoney();document.body.classList.toggle('dark',!!data.settings.darkMode);$('dashBalance').textContent=signedDuration(b);$('dashBalance').className='big '+(b>=0?'positive':'negative');$('dashMoneyDiff').textContent=(openMoney>0?'+':'')+euro(openMoney);$('dashMoneyDiff').className='big '+(openMoney>0?'money-open':'money-ok');$('dashEarned').textContent=euro(t.workedPay);$('dashEarned').previousElementSibling.textContent=`Erarbeitet ${y}`;$('dashTips').textContent=euro(t.tips);renderCurrentMonth();renderMonths(y);renderDays();renderReports();renderSettings();renderBackupStatus();renderAssistant()}



/* ===== v6.0 Alltag & Monatsabschluss ===== */
(function(){
  function ensureV6(){
    data.settings=data.settings||{};
    if(data.settings.autoBackupEnabled===undefined)data.settings.autoBackupEnabled=true;
    data.autoBackups=Array.isArray(data.autoBackups)?data.autoBackups:[];
    data.monthClosures=(data.monthClosures&&typeof data.monthClosures==='object')?data.monthClosures:{};
    data.payments=Array.isArray(data.payments)?data.payments:[];
    data.payments.forEach(p=>{if(p.confirmed===undefined)p.confirmed=true});
  }
  ensureV6();

  window.v6Audit=function(action,detail=''){
    data.audit=Array.isArray(data.audit)?data.audit:[];
    data.audit.unshift({id:Date.now(),at:new Date().toISOString(),action,detail});
    if(data.audit.length>250)data.audit=data.audit.slice(0,250);
  };

  window.createAutoBackup=function(reason='Änderung'){
    ensureV6();
    if(!data.settings.autoBackupEnabled)return;
    const snap={
      id:Date.now(),
      at:new Date().toISOString(),
      reason,
      data:JSON.parse(JSON.stringify({...data,autoBackups:[]}))
    };
    data.autoBackups.unshift(snap);
    if(data.autoBackups.length>8)data.autoBackups=data.autoBackups.slice(0,8);
    data.settings.lastAutoBackupAt=snap.at;
    localStorage.setItem('stundenkontoGrueterV6AutoBackup',JSON.stringify(data.autoBackups));
  };

  window.toggleAutoBackup=function(v){
    data.settings.autoBackupEnabled=!!v;
    v6Audit('Automatische Sicherung',v?'aktiviert':'deaktiviert');
    if(v)createAutoBackup('Automatische Sicherung aktiviert');
    localStorage.setItem(key,JSON.stringify(data));
    render();
  };

  window.quickToday=function(){
    const ds=new Date().toISOString().slice(0,10);
    const idx=data.days.findIndex(d=>d.date===ds);
    if(idx>=0){openDay(idx);return}
    openCalendarDate(ds,-1);
    const dow=new Date(ds+'T12:00:00').getDay();
    if((data.settings.routineDays||[2,4]).includes(dow)){
      $('dStart').value=data.settings.routineStart||'15:00';
      $('dEnd').value=data.settings.routineEnd||'20:00';
    }else{
      $('dStart').value=data.settings.routineStart||'15:00';
      $('dEnd').value='';
    }
    updateDayPreview();
  };

  function routineDatesForMonth(k){
    const [y,m]=k.split('-').map(Number), out=[],days=new Date(y,m,0).getDate();
    for(let d=1;d<=days;d++){
      const dt=new Date(y,m-1,d,12), ds=`${y}-${String(m).padStart(2,'0')}-${String(d).padStart(2,'0')}`;
      if((data.settings.routineDays||[2,4]).includes(dt.getDay()))out.push(ds);
    }
    return out;
  }
  function nextPlannedRoutineDate(k){
    const today=new Date().toISOString().slice(0,10);
    return routineDatesForMonth(k).find(ds=>ds>=today&&!data.days.some(d=>d.date===ds))||null;
  }
  function forecastForCurrent(){
    const k=actualCurrentKey(),x=calcMonth(k),limit=x.limit||603,remaining=Math.max(0,limit-x.workedPay),
      remainingMinutes=x.rate?Math.floor(remaining/x.rate*60):0,
      avg=avgDay(k),routine=routineShiftMinutes(),base=avg>=180?avg:routine,
      full=base?Math.floor(remainingMinutes/base):0,remainder=base?remainingMinutes-full*base:remainingMinutes;
    const dates=nextRoutineDates(Math.max(1,full+1));
    let reach=null;
    if(full>0&&dates.length>=full)reach=dates[full-1];
    else if(remainingMinutes>0&&dates.length)reach=dates[0];
    return {k,x,limit,remaining,remainingMinutes,avg,routine,base,full,remainder,reach};
  }

  window.renderV6Dashboard=function(){
    ensureV6();
    const f=forecastForCurrent(), k=f.k, x=f.x, next=nextPlannedRoutineDate(k);
    if($('v6ForecastCard')){
      const reachTxt=f.reach?f.reach.toLocaleDateString('de-DE',{weekday:'long',day:'2-digit',month:'2-digit'}):'–';
      $('v6ForecastCard').innerHTML=`<h2 style="margin-top:0">Auszahlungs- & Arbeitsprognose</h2>
        <div class="v6-grid">
          <div class="v6-kpi"><b>${duration(f.remainingMinutes)}</b><span>noch mögliche Arbeitszeit</span></div>
          <div class="v6-kpi"><b>${f.full}</b><span>volle Routine-Einsätze</span></div>
          <div class="v6-kpi"><b>${reachTxt}</b><span>voraussichtlicher Grenzzeitpunkt</span></div>
          <div class="v6-kpi"><b>${next?new Date(next+'T12:00:00').toLocaleDateString('de-DE'):'–'}</b><span>nächster geplanter Einsatz</span></div>
        </div>
        <div class="small" style="margin-top:10px">Berechnung mit ${f.avg?'deinem bisherigen Durchschnitt':'deiner Di/Do-Routine'} von etwa ${duration(f.base)} je Einsatz. Geplante Tage zählen erst nach dem Speichern als Arbeitszeit.</div>`;
    }
    if($('v6CloseCard'))renderV6CloseCard();
  };

  function closureState(k){
    const m=calcMonth(k),days=monthDays(k),pay=paymentsFor(k),c=data.monthClosures[k]||{};
    const steps=[
      {id:'days',label:'Arbeitstage erfasst',done:days.length>0},
      {id:'official',label:'Arbeitgeberzeit eingetragen',done:m.officialMinutes>0},
      {id:'compare',label:'Zeiten abgeglichen',done:m.officialMinutes>0&&m.officialDiff===0},
      {id:'pay',label:'Auszahlung erfasst',done:pay.length>0},
      {id:'received',label:'Zahlungseingang bestätigt',done:pay.some(p=>p.confirmed)}
    ];
    return {m,steps,done:steps.filter(s=>s.done).length,complete:steps.every(s=>s.done),closed:!!c.closed,closedAt:c.closedAt||''};
  }

  window.renderV6CloseCard=function(){
    const k=actualCurrentKey(),state=closureState(k),[y,m]=k.split('-').map(Number);
    const cls=state.complete?'':'warn';
    $('v6CloseCard').innerHTML=`<h2 style="margin-top:0">Monatsabschluss ${MONTHS[m-1]} ${y}</h2>
      <div class="v6-status ${cls}"><b>${state.done}/5 Punkte erledigt</b><div class="small">${state.complete?'Der Monat ist bereit für den Abschluss.':'Die offenen Punkte kannst du nach und nach ergänzen.'}</div></div>
      <div class="v6-steps">${state.steps.map(s=>`<div class="v6-step ${s.done?'done':''}"><span>${s.done?'✓':'○'} ${s.label}</span><b>${s.done?'erledigt':'offen'}</b></div>`).join('')}</div>
      <div style="height:10px"></div><button class="btn gold full" onclick="closeCurrentMonthV6()" ${state.complete?'':'disabled'}>${state.closed?'Monat erneut sichern':'Monat abschließen'}</button>`;
  };

  window.closeCurrentMonthV6=function(){
    const k=actualCurrentKey(),s=closureState(k);
    if(!s.complete){alert('Der Monat ist noch nicht vollständig. Bitte zuerst alle fünf Punkte erledigen.');return}
    data.monthClosures[k]={closed:true,closedAt:new Date().toISOString(),workedMinutes:s.m.workedMinutes,officialMinutes:s.m.officialMinutes,paidMinutes:s.m.paidMinutes};
    v6Audit('Monatsabschluss',k);
    createAutoBackup('Monatsabschluss '+k);
    localStorage.setItem(key,JSON.stringify(data));
    render();
    alert('Monat abgeschlossen und Sicherungspunkt erstellt.');
  };

  window.renderV6Compare=function(){
    if(!$('v6MonthCompare'))return;
    const y=Number(data.settings.currentYear),months=yearMonths(y).filter(([,m])=>m.workedMinutes>0).slice(-6);
    if(!months.length){$('v6MonthCompare').innerHTML='<div class="small">Noch nicht genug Monatsdaten vorhanden.</div>';return}
    const max=Math.max(...months.map(([,m])=>m.workedMinutes),1);
    $('v6MonthCompare').innerHTML=months.slice().reverse().map(([k,m],i,arr)=>{
      const prev=months[months.findIndex(x=>x[0]===k)-1];
      const diff=prev?m.workedMinutes-prev[1].workedMinutes:null;
      return `<div class="v6-compare-row"><b>${MONTHS[Number(k.slice(5))-1].slice(0,3)} ${k.slice(2,4)}</b><div class="v6-compare-track"><div class="v6-compare-fill" style="width:${Math.max(3,m.workedMinutes/max*100)}%"></div></div><div style="text-align:right"><b>${duration(m.workedMinutes)}</b>${diff!==null?`<div class="small">${signedDuration(diff)}</div>`:''}</div></div>`;
    }).join('');
  };

  window.renderV6ClosedMonths=function(){
    if(!$('v6ClosedMonths'))return;
    const keys=Object.keys(data.monthClosures||{}).sort().reverse();
    $('v6ClosedMonths').innerHTML=keys.length?keys.map(k=>{
      const c=data.monthClosures[k],m=calcMonth(k),received=paymentsFor(k).some(p=>p.confirmed);
      return `<div class="v6-close-item"><div class="row"><div style="flex:1"><b>${MONTHS[Number(k.slice(5))-1]} ${k.slice(0,4)}</b><div class="small">Abgeschlossen ${c.closedAt?new Date(c.closedAt).toLocaleString('de-DE'):'–'}</div></div><div style="text-align:right"><b>${duration(m.workedMinutes)}</b><div class="small">${received?'✓ bezahlt':'Zahlung offen'}</div></div></div></div>`;
    }).join(''):'<div class="small">Noch kein Monat ausdrücklich abgeschlossen.</div>';
  };

  window.renderV6AutoBackup=function(){
    ensureV6();
    if($('autoBackupToggle'))$('autoBackupToggle').checked=!!data.settings.autoBackupEnabled;
    if($('v6AutoBackupStatus')){
      const at=data.settings.lastAutoBackupAt?new Date(data.settings.lastAutoBackupAt).toLocaleString('de-DE'):'noch keine';
      $('v6AutoBackupStatus').innerHTML=`<b>${data.autoBackups.length} lokale Sicherungspunkte</b><br>Letzte automatische Sicherung: ${at}`;
    }
  };

  window.askQuick=function(q){
    $('assistantInput').value=q;
    runAssistant();
  };

  // Override calendar: future regular days get a planned marker, but never count until saved.
  const oldRenderCalendar=renderCalendar;
  renderCalendar=function(){
    if(!$('calendarGrid'))return oldRenderCalendar();
    const y=calendarDate.getFullYear(),m=calendarDate.getMonth(),daysIn=new Date(y,m+1,0).getDate(),
      first=(new Date(y,m,1).getDay()+6)%7,labels=['Mo','Di','Mi','Do','Fr','Sa','So'],
      today=new Date().toISOString().slice(0,10);
    $('calendarTitle').textContent=`${MONTHS[m]} ${y}`;
    let html=labels.map(x=>`<div class="cal-label">${x}</div>`).join('');
    for(let i=0;i<first;i++)html+='<div class="cal-day empty"></div>';
    for(let d=1;d<=daysIn;d++){
      const ds=`${y}-${String(m+1).padStart(2,'0')}-${String(d).padStart(2,'0')}`,
        idx=data.days.findIndex(x=>x.date===ds),entry=idx>=0?data.days[idx]:null,
        dow=new Date(y,m,d).getDay(),routine=(data.settings.routineDays||[2,4]).includes(dow),
        planned=routine&&!entry&&ds>=today;
      html+=`<div class="cal-day ${entry?'work':''} ${routine?'routine':''} ${planned?'planned':''} ${ds===today?'today':''}" onclick="openCalendarDate('${ds}',${idx})"><b>${d}</b>${entry?`<span class="cal-hours">${duration(dayMinutes(entry))}</span>`:(planned?`<span class="v6-planned">${data.settings.routineStart||'15:00'}–${data.settings.routineEnd||'20:00'}</span>`:'')}</div>`;
    }
    $('calendarGrid').innerHTML=html;
  };

  // Payment confirmed flag.
  const oldSavePayment=savePayment;
  savePayment=function(){
    const beforeLen=data.payments.length;
    const confirmed=$('pConfirmed')?$('pConfirmed').checked:true;
    oldSavePayment();
    if(data.payments.length>beforeLen){
      data.payments[data.payments.length-1].confirmed=confirmed;
      v6Audit('Zahlung '+(confirmed?'bestätigt':'gebucht, Eingang offen'),data.payments[data.payments.length-1].month);
      createAutoBackup('Auszahlung geändert');
      localStorage.setItem(key,JSON.stringify(data));
      render();
    }
  };

  // Automatic change snapshots around the most important edits.
  const oldSaveDayV6=saveDay;
  saveDay=function(){
    const edit=$('dayModal').dataset.edit, date=$('dDate').value;
    oldSaveDayV6();
    createAutoBackup(edit!==''?'Arbeitstag geändert':'Arbeitstag hinzugefügt');
    v6Audit(edit!==''?'Arbeitstag geändert':'Arbeitstag hinzugefügt',date);
    localStorage.setItem(key,JSON.stringify(data));render();
  };
  const oldDeleteDayV6=deleteDay;
  deleteDay=function(){
    oldDeleteDayV6();
    createAutoBackup('Arbeitstag gelöscht');
    localStorage.setItem(key,JSON.stringify(data));render();
  };

  // Extend assistant with concrete data questions.
  const oldRunAssistant=runAssistant;
  runAssistant=function(){
    const q=($('assistantInput').value||'').trim(),s=q.toLowerCase(),k=actualCurrentKey(),f=forecastForCurrent();
    if(!q)return oldRunAssistant();

    if((/wie viel|wieviel/.test(s))&&(/noch arbeiten|restarbeitszeit|darf ich/.test(s))){
      assistantAnswer(`Du kannst diesen Monat rechnerisch noch ${duration(f.remainingMinutes)} arbeiten. Das sind bei deiner üblichen Schicht von etwa ${duration(f.base)} noch ${f.full} volle Einsätze${f.remainder?` plus ${duration(f.remainder)} Restzeit`:''}.`);
      return;
    }
    if(/wann/.test(s)&&(/grenze|minijob/.test(s))){
      assistantAnswer(f.reach?`Bei deinem bisherigen Rhythmus würdest du die Monatsgrenze ungefähr am ${f.reach.toLocaleDateString('de-DE',{weekday:'long',day:'2-digit',month:'2-digit'})} erreichen. Die Prognose passt sich nach jedem gespeicherten Arbeitstag neu an.`:'Mit den aktuellen Daten ist noch kein konkreter Grenztermin erforderlich.');
      return;
    }
    if(/welche monate/.test(s)&&(/nicht.*bezahlt|offen/.test(s))){
      const open=Object.keys(data.months).sort().filter(mk=>mk<actualCurrentKey()).filter(mk=>{
        const cm=calcMonth(mk);return cm.diffMinutes>0||!paymentsFor(mk).some(p=>p.confirmed);
      });
      assistantAnswer(open.length?`Noch nicht vollständig erledigt: ${open.map(mk=>`${MONTHS[Number(mk.slice(5))-1]} ${mk.slice(0,4)}`).join(', ')}.`:'Alle abgeschlossenen Monate sind nach deinen gespeicherten Daten bezahlt bzw. ausgeglichen.');
      return;
    }
    if(/seit juli/.test(s)){
      const y=Number(data.settings.currentYear),from=`${y}-07`,mins=data.days.filter(d=>d.date&&d.date.slice(0,7)>=from&&d.date.startsWith(y+'-')).reduce((a,d)=>a+dayMinutes(d),0);
      const earn=Object.keys(data.months).filter(mk=>mk>=from&&mk.startsWith(y+'-')).reduce((a,mk)=>a+calcMonth(mk).workedPay,0);
      assistantAnswer(`Seit Juli ${y} hast du ${duration(mins)} gearbeitet und damit rechnerisch ${euro(earn)} erarbeitet.`);
      return;
    }
    oldRunAssistant();
  };

  // Extend render without disturbing the stable v5 UI.
  const oldRenderV6=render;
  render=function(){
    ensureV6();
    oldRenderV6();
    renderV6Dashboard();
    renderV6Compare();
    renderV6ClosedMonths();
    renderV6AutoBackup();
  };

  // Mark app version and create first v6 safety snapshot without triggering dialogs.
  data.backupVersion=4;
  data.appVersion='6.1.0';
  if(!data.settings.v6Initialized){
    data.settings.v6Initialized=true;
    createAutoBackup('Update auf v6.0');
    localStorage.setItem(key,JSON.stringify(data));
  }
})();



/* ===== v6.1 Feinschliff & Logikkorrekturen ===== */
(function(){
  const V61='6.1.0';
  data.backupVersion=5;
  data.appVersion=V61;

  function currentDayOfMonth(){ return new Date().getDate(); }
  function currentMonthKeyV61(){ return actualCurrentKey(); }
  let closeManuallyOpened=false;

  function monthOpenValuesForYear(y){
    const nowKey=actualCurrentKey();
    let min=0,money=0;
    Object.keys(data.months||{}).sort().forEach(k=>{
      if(!k.startsWith(String(y)+'-')) return;
      // Current/future months are not outstanding claims.
      if(k>=nowKey) return;
      const m=calcMonth(k);
      min+=m.diffMinutes||0;
      money+=m.earnDiff||0;
    });
    return {minutes:min,money};
  }

  // Dashboard yearly label must stay "Jahresverdienst".
  function setAnnualDashboardLabel(){
    const el=$('dashEarned');
    if(el && el.previousElementSibling) el.previousElementSibling.textContent='Jahresverdienst';
  }

  // Current month = current facts only. Forecast lives in its own block.
  renderCurrentMonth=function(){
    const k=actualCurrentKey(),[y,m]=k.split('-').map(Number),x=calcMonth(k),
      limit=x.limit||603,pctRaw=limit>0?x.workedPay/limit*100:0,pct=Math.max(0,Math.min(100,pctRaw)),
      remaining=Math.max(0,limit-x.workedPay),
      remainingMinutes=x.rate>0?Math.floor(remaining/x.rate*60):0;
    let cls='ok',msg='Alles im grünen Bereich.';
    if(pctRaw>=100){cls='over';msg=`Grenze erreicht/überschritten um ${euro(Math.max(0,x.workedPay-limit))}.`}
    else if(pctRaw>=90){cls='warn90';msg='Über 90 % der Monatsgrenze – weitere Einsätze genau planen.'}
    else if(pctRaw>=80){cls='warn80';msg='Über 80 % der Monatsgrenze – Restarbeitszeit im Blick behalten.'}

    $('currentMonthCard').innerHTML=`<div class="current-head">
      <div><div class="small">AKTUELLER MONAT</div><div class="current-title">${MONTHS[m-1]} ${y}</div></div>
    </div>
    <div class="current-extra">
      <div><b>${duration(x.workedMinutes)}</b><span>Gearbeitet</span></div>
      <div><b>${euro(x.workedPay)}</b><span>Erarbeitet</span></div>
      <div><b>${euro(remaining)}</b><span>Rest bis ${euro(limit)}</span></div>
      <div><b>${duration(remainingMinutes)}</b><span>Restarbeitszeit</span></div>
    </div>
    <div class="limitbar"><i style="width:${pct}%"></i></div>
    <div class="minirow"><span>${euro(x.workedPay)} von ${euro(limit)}</span><span>${fmt(pctRaw,0)} %</span></div>
    <div class="limit-warning ${cls}">${msg}</div>`;

    const b=closedBalance(),money=closedOpenMoney();
    $('closedAccountStrip').innerHTML=`<div><b>Stundenkonto aus Vormonaten</b><br><span>${b>0?'Guthaben beim Arbeitgeber':b<0?'Überzahlung / Minussaldo':'aktuell ausgeglichen'}</span></div>
      <div style="text-align:right"><b class="${b>=0?'positive':'negative'}">${signedDuration(b)}</b><br><span>${money>=0?'+':''}${euro(money)}</span></div>`;
  };

  function forecastV61(){
    const k=actualCurrentKey(),x=calcMonth(k),limit=x.limit||603,
      remaining=Math.max(0,limit-x.workedPay),
      remainingMinutes=x.rate?Math.floor(remaining/x.rate*60):0,
      avg=avgDay(k),routine=routineShiftMinutes(),base=avg>=180?avg:routine,
      full=base?Math.floor(remainingMinutes/base):0,
      remainder=base?remainingMinutes-full*base:remainingMinutes;
    const countNeeded = remainingMinutes<=0 ? 0 : full + (remainder>0?1:0);
    const dates=nextRoutineDates(Math.max(1,countNeeded));
    const reach=countNeeded>0 && dates.length>=countNeeded ? dates[countNeeded-1] : null;
    const next=dates.length?dates[0]:null;
    return {k,x,limit,remaining,remainingMinutes,avg,routine,base,full,remainder,countNeeded,reach,next};
  }

  renderV6Dashboard=function(){
    const f=forecastV61();
    if($('v6ForecastCard')){
      const need=f.remainingMinutes<=0?'Grenze erreicht':
        `${f.full} ${f.full===1?'Einsatz':'Einsätze'}${f.remainder?` + ${duration(f.remainder)}`:''}`;
      const reachTxt=f.reach?f.reach.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',year:'numeric'}):'–';
      const nextTxt=f.next?f.next.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',year:'numeric'}):'–';
      $('v6ForecastCard').innerHTML=`<h2 style="margin-top:0">Monatsprognose</h2>
        <div class="v6-grid">
          <div class="v6-kpi"><b>${duration(f.remainingMinutes)}</b><span>noch mögliche Arbeitszeit</span></div>
          <div class="v6-kpi"><b>${need}</b><span>voraussichtlich noch nötig</span></div>
          <div class="v6-kpi"><b>${nextTxt}</b><span>nächster geplanter Einsatz</span></div>
          <div class="v6-kpi"><b>${reachTxt}</b><span>Grenze voraussichtlich erreicht</span></div>
        </div>
        <div class="small" style="margin-top:10px">Prognose auf Basis deines bisherigen Durchschnitts. Geplante Tage zählen erst nach dem Speichern.</div>`;
    }
    renderV6CloseCard();
  };

  function closureStateV61(k){
    const m=calcMonth(k),days=monthDays(k),pay=paymentsFor(k),c=(data.monthClosures||{})[k]||{};
    const steps=[
      {id:'days',label:'Arbeitstage vollständig',done:days.length>0},
      {id:'official',label:'Arbeitgeberzeit eingetragen',done:m.officialMinutes>0},
      {id:'compare',label:'Abweichung geprüft',done:m.officialMinutes>0&&m.officialDiff===0},
      {id:'pay',label:'Auszahlung eingetragen',done:pay.length>0},
      {id:'received',label:'Zahlungseingang bestätigt',done:pay.some(p=>p.confirmed)}
    ];
    return {m,steps,done:steps.filter(s=>s.done).length,complete:steps.every(s=>s.done),closed:!!c.closed,closedAt:c.closedAt||''};
  }

  window.openMonthCloseEarly=function(){
    closeManuallyOpened=true;
    renderV6CloseCard();
  };

  renderV6CloseCard=function(){
    if(!$('v6CloseCard'))return;
    const k=actualCurrentKey(),state=closureStateV61(k),[y,m]=k.split('-').map(Number),day=currentDayOfMonth();

    if(state.closed){
      $('v6CloseCard').innerHTML=`<div class="v61-close-compact"><div><b>Monatsabschluss ${MONTHS[m-1]} ${y}</b>
        <div class="small">Monat abgeschlossen${state.closedAt?` · ${new Date(state.closedAt).toLocaleDateString('de-DE')}`:''}</div></div><span class="pill">✓ erledigt</span></div>`;
      return;
    }

    if(day<28 && !closeManuallyOpened){
      $('v6CloseCard').innerHTML=`<div class="v61-close-compact"><div><b>Monatsabschluss ab 28. verfügbar</b>
        <div class="small">Bis dahin bleibt der Bereich kompakt.</div></div><button class="btn secondary smallbtn" onclick="openMonthCloseEarly()">Jetzt öffnen</button></div>`;
      return;
    }

    const cls=state.complete?'':'warn';
    $('v6CloseCard').innerHTML=`<h2 style="margin-top:0">Monatsabschluss ${MONTHS[m-1]} ${y}</h2>
      <div class="v6-status ${cls}"><b>${state.done}/5 Punkte erledigt</b><div class="small">${state.complete?'Der Monat ist bereit für den Abschluss.':'Die offenen Punkte kannst du nach und nach ergänzen.'}</div></div>
      <div class="v6-steps">${state.steps.map(s=>`<div class="v6-step ${s.done?'done':''}"><span>${s.done?'✓':'○'} ${s.label}</span><b>${s.done?'erledigt':'offen'}</b></div>`).join('')}</div>
      <div style="height:10px"></div><button class="btn gold full" onclick="closeCurrentMonthV6()" ${state.complete?'':'disabled'}>Monat abschließen</button>`;
  };

  closeCurrentMonthV6=function(){
    const k=actualCurrentKey(),s=closureStateV61(k);
    if(currentDayOfMonth()<28 && !closeManuallyOpened){
      alert('Der Monatsabschluss wird regulär ab dem 28. aktiviert. Du kannst ihn vorher über „Jetzt öffnen“ manuell öffnen.');
      return;
    }
    if(!s.complete){alert('Der Monat ist noch nicht vollständig. Bitte zuerst alle fünf Punkte erledigen.');return}
    data.monthClosures=data.monthClosures||{};
    data.monthClosures[k]={closed:true,closedAt:new Date().toISOString(),workedMinutes:s.m.workedMinutes,officialMinutes:s.m.officialMinutes,paidMinutes:s.m.paidMinutes};
    if(window.v6Audit)v6Audit('Monatsabschluss',k);
    if(window.createAutoBackup)createAutoBackup('Monatsabschluss '+k);
    data.appVersion=V61;
    localStorage.setItem(key,JSON.stringify(data));
    render();
    alert('Monat abgeschlossen und Sicherungspunkt erstellt.');
  };

  // Days list follows the calendar month.
  function renderV61DayList(){
    if(!$('dayList'))return;
    const prefix=`${calendarDate.getFullYear()}-${String(calendarDate.getMonth()+1).padStart(2,'0')}`;
    const arr=data.days.map((d,i)=>({...d,_index:i}))
      .filter(d=>(d.date||'').startsWith(prefix))
      .sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    if(!arr.length){
      $('dayList').innerHTML=`<div class="card small">Für ${MONTHS[calendarDate.getMonth()]} ${calendarDate.getFullYear()} sind noch keine Arbeitstage erfasst.</div>`;
      return;
    }
    $('dayList').innerHTML=arr.map(d=>`<div class="month" onclick="openDay(${d._index})"><div class="monthhead"><div>
      <div class="monthtitle">${new Date(d.date+'T12:00:00').toLocaleDateString('de-DE')}</div>
      <div class="small">${d.start||'–'} bis ${d.end||'–'} · Pause ${d.breakMin||0} Min.</div>
      ${d.note?`<div class="small" style="margin-top:5px">${esc(d.note)}</div>`:''}
      </div><b>${duration(dayMinutes(d))}</b></div></div>`).join('');
  }
  renderDays=function(){ renderCalendar(); renderV61DayList(); };
  changeCalendarMonth=function(delta){ calendarDate.setMonth(calendarDate.getMonth()+delta); renderCalendar(); renderV61DayList(); };

  // Reports: current month is not an outstanding claim.
  const oldRenderReportsV61=renderReports;
  renderReports=function(){
    oldRenderReportsV61();
    const selectedYear=Number($('reportYear').value||data.settings.currentYear);
    const t=totals(selectedYear),open=monthOpenValuesForYear(selectedYear);
    if($('reportBox')){
      $('reportBox').innerHTML=`<div class="summaryline">
        <div><b>${duration(t.workedMinutes)}</b><span>gearbeitet</span></div>
        <div><b>${duration(t.paidMinutes)}</b><span>ausgezahlte Zeit</span></div>
        <div><b class="${open.minutes>0?'money-open':'money-ok'}">${signedDuration(open.minutes)}</b><span>offenes Stundenguthaben</span></div>
        <div><b>${euro(t.workedPay)}</b><span>Jahresverdienst</span></div>
        <div><b>${euro(t.paidSalary)}</b><span>Rechnerisch ausgezahlt</span></div>
        <div><b class="${open.money>0?'money-open':'money-ok'}">${euro(open.money)}</b><span>offenes Gehalt</span></div>
        <div><b>${euro(t.tips)}</b><span>Trinkgeld</span></div>
        <div><b>${euro(t.totalPaid)}</b><span>inkl. Trinkgeld</span></div>
      </div>`;
    }
    renderStats();
    renderPayoutHistory();
    renderAudit();
  };

  renderStats=function(){
    if(!$('statsBox'))return;
    const y=Number(data.settings.currentYear),ms=yearMonths(y),
      allDays=data.days.filter(d=>(d.date||'').startsWith(y+'-')),
      mins=allDays.reduce((s,d)=>s+dayMinutes(d),0),
      earn=ms.reduce((s,[,m])=>s+m.workedPay,0),
      tips=ms.reduce((s,[,m])=>s+m.tips,0),
      avgM=allDays.length?Math.round(mins/allDays.length):0;
    $('statsBox').innerHTML=`<div class="summaryline">
      <div><b>${allDays.length}</b><span>Einsätze ${y}</span></div>
      <div><b>${avgM?duration(avgM):'–'}</b><span>Ø pro Einsatz</span></div>
      <div><b>${allDays.length?euro(earn/allDays.length):'–'}</b><span>Ø Verdienst/Einsatz</span></div>
      <div><b>${euro(tips)}</b><span>Trinkgeld</span></div>
    </div>`;
  };

  renderV6Compare=function(){
    if(!$('v6MonthCompare'))return;
    const y=Number(data.settings.currentYear),months=yearMonths(y).filter(([,m])=>m.workedMinutes>0).slice(-6);
    if(!months.length){$('v6MonthCompare').innerHTML='<div class="small">Noch nicht genug Monatsdaten vorhanden.</div>';return}
    const max=Math.max(...months.map(([,m])=>m.workedMinutes),1),current=actualCurrentKey();
    $('v6MonthCompare').innerHTML=months.slice().reverse().map(([k,m])=>{
      const idx=months.findIndex(x=>x[0]===k),prev=idx>0?months[idx-1]:null,diff=prev?m.workedMinutes-prev[1].workedMinutes:null;
      const status=(k===current && !(data.monthClosures||{})[k]?.closed) ? 'laufender Monat' : (diff!==null?signedDuration(diff):'');
      return `<div class="v6-compare-row"><b>${MONTHS[Number(k.slice(5))-1].slice(0,3)} ${k.slice(2,4)}</b>
        <div class="v6-compare-track"><div class="v6-compare-fill" style="width:${Math.max(3,m.workedMinutes/max*100)}%"></div></div>
        <div style="text-align:right"><b>${duration(m.workedMinutes)}</b>${status?`<div class="small">${status}</div>`:''}</div></div>`;
    }).join('');
  };

  renderPayoutHistory=function(){
    if(!$('payoutHistory'))return;
    const ps=(data.payments||[]).slice().sort((a,b)=>(b.date||'').localeCompare(a.date||''));
    $('payoutHistory').innerHTML=ps.length?ps.map(p=>{
      const mk=p.month||'',label=mk?`${MONTHS[Number(mk.slice(5))-1]} ${mk.slice(0,4)}`:'Auszahlung';
      return `<div class="payment"><div><b>${label}</b><br><span>${p.date?new Date(p.date+'T12:00:00').toLocaleDateString('de-DE'):'ohne Buchungsdatum'}${p.note?' · '+esc(p.note):''}</span></div>
        <div style="text-align:right"><b>${duration(p.hoursMinutes)} · ${euro(p.amount)}</b><br><span>${p.confirmed?'✓ Zahlung bestätigt':'○ Zahlung noch offen'}</span></div></div>`;
    }).join(''):'<div class="small">Noch keine Auszahlungen gebucht.</div>';
  };

  // Compact, deduplicated audit history. Supports both old {ts} and v6 {at}.
  renderAudit=function(){
    if(!$('auditLog'))return;
    const raw=(data.audit||[]).slice().sort((a,b)=>{
      const ta=new Date(a.at||a.ts||0).getTime(),tb=new Date(b.at||b.ts||0).getTime();return tb-ta;
    });
    const seen=new Set(),out=[];
    for(const x of raw){
      const when=x.at||x.ts||'',key=`${x.action}|${x.detail||''}|${String(when).slice(0,16)}`;
      if(seen.has(key))continue;seen.add(key);out.push(x);if(out.length>=60)break;
    }
    $('auditLog').innerHTML=out.length?out.map(x=>{
      const d=new Date(x.at||x.ts||Date.now());
      return `<div class="v61-audit-row"><b>${d.toLocaleString('de-DE')}</b><br><span>${esc(x.action)}${x.detail?` · ${esc(x.detail)}`:''}</span></div>`;
    }).join(''):'<div class="small">Noch keine Änderungen protokolliert.</div>';
  };

  // Assistant: no missing employer-time warning before the 28th.
  const oldRenderAssistantV61=renderAssistant;
  renderAssistant=function(){
    oldRenderAssistantV61();
    if($('assistantAnswer') && !$('assistantAnswer').dataset.userAnswer){
      if($('assistantAnswer').textContent.includes('Ich kann deine Stunden')) $('assistantAnswer').textContent='Fragen zu Stunden, offenen Beträgen und Monatsgrenze.';
    }
    const k=actualCurrentKey(),x=calcMonth(k),day=currentDayOfMonth();
    if($('assistantMonthCheck') && day<28 && !x.officialMinutes){
      $('assistantMonthCheck').innerHTML='<b>Aktuell keine Auffälligkeiten</b><div class="small" style="margin-top:5px">Die Arbeitgeberzeit wird regulär erst zum Monatsende relevant.</div>';
    }
  };

  // Settings: clearer history message, no duplicated audit block here.
  const oldRenderSettingsV61=renderSettings;
  renderSettings=function(){
    oldRenderSettingsV61();
    if($('historyInfo')){
      $('historyInfo').innerHTML='<b>Historie</b><br>Änderungen gelten ab dem aktuellen Monat. Frühere Monate bleiben unverändert.';
    }
    renderV6AutoBackup();
  };

  renderV6AutoBackup=function(){
    if($('autoBackupToggle'))$('autoBackupToggle').checked=!!data.settings.autoBackupEnabled;
    if($('v6AutoBackupStatus')){
      const n=(data.autoBackups||[]).length,at=data.settings.lastAutoBackupAt?new Date(data.settings.lastAutoBackupAt).toLocaleString('de-DE'):'noch keine';
      const points=n===1?'1 lokaler Sicherungspunkt':`${n} lokale Sicherungspunkte`;
      $('v6AutoBackupStatus').innerHTML=`<b>${points}</b><br>Letzte automatische Sicherung: ${at}`;
    }
  };

  // Correct backup metadata.
  exportBackup=function(){
    data.settings.lastBackupAt=Date.now();
    data.backupVersion=5;data.appVersion=V61;data.createdAt=new Date().toISOString();
    localStorage.setItem(key,JSON.stringify(data));
    saveTextFile(backupFileName(),JSON.stringify(data,null,2),'application/json');
    if(window.Android&&Android.updateBackupTimestamp)Android.updateBackupTimestamp(data.settings.lastBackupAt);
    renderBackupStatus();
  };
  exportBackupCloud=function(){
    data.settings.lastBackupAt=Date.now();
    data.backupVersion=5;data.appVersion=V61;data.createdAt=new Date().toISOString();
    localStorage.setItem(key,JSON.stringify(data));
    if(window.Android&&Android.saveBackupToCloud)Android.saveBackupToCloud(backupFileName(),JSON.stringify(data,null,2));
    else alert('Externes Speichern ist nur in der Android-App verfügbar.');
    renderBackupStatus();
  };

  // Prevent v6 wrapper from writing duplicate audit entries for workday edits.
  // The v5 audit wrapper already logs add/change/delete; v6.1 only adds a backup snapshot.
  // Replace final wrappers with clean versions around the original low-level functions where possible.
  if(!data.settings.v61Initialized){
    data.settings.v61Initialized=true;
    data.appVersion=V61;
    if(window.createAutoBackup)createAutoBackup('Update auf v6.1');
    localStorage.setItem(key,JSON.stringify(data));
  }

  // Final render wrapper.
  const renderBeforeV61=render;
  render=function(){
    data.appVersion=V61;
    renderBeforeV61();
    setAnnualDashboardLabel();
    renderV6Dashboard();
    renderV6Compare();
    renderV6ClosedMonths();
    renderV6AutoBackup();
    renderAudit();
  };

  // Apply immediately after script load.
  setAnnualDashboardLabel();
})();
